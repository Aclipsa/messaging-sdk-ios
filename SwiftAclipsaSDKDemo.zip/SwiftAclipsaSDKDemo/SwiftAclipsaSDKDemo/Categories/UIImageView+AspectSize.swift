//
//  UIImageView+AspectSize.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit

extension UIImageView
{
    func imageScale() -> CGSize
    {
        let sx: Float = Float(self.frame.size.width / self.image!.size.width)
        let sy: Float = Float(self.frame.size.width / self.image!.size.height)
        var s: Float = 1.0
        
        switch(self.contentMode)
        {
        case UIViewContentMode.ScaleAspectFit:
            s = fminf(sx, sy)
            return CGSizeMake(CGFloat(s), CGFloat(s))
            
        case UIViewContentMode.ScaleAspectFill:
            s = fmaxf(sx, sy)
            return CGSizeMake(CGFloat(s), CGFloat(s))
            
        case UIViewContentMode.ScaleToFill:
            return CGSizeMake(CGFloat(sx), CGFloat(sy))
            
        default:
            return CGSizeMake(CGFloat(s), CGFloat(s))
        }
    }
}
