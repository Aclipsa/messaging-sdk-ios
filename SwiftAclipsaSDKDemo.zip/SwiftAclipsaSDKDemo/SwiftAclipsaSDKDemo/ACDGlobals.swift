//
//  ACDGlobals.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit

var ACLIPSA_APP_ID = "3113"

var MAX_RECORD_TIME = 30
var MIN_FREE_DISK_SPACE = (1024 * 1024)

var GROW_ANIMATION_DURATION_SECONDS = 0.2
var SHRINK_ANIMATION_DURATION_SECONDS  = 0.2

var SECOND = 1
var MINUTE = (60 * SECOND)
var HOUR = (60 * MINUTE)
var DAY = (24 * HOUR)
var MONTH = (30 * DAY)

var ACTION_MENU_TEXT_COLOR = UIColor(red: 51/255.0, green: 51/255.0, blue: 51/255.0, alpha: 1.0)
var ACTION_MENU_SHADOW_COLOR = UIColor(red: 254/255.0, green: 216/255.0, blue: 164/255.0, alpha: 1.0)

var MINUTE_BAR_FIRST_CHUNK = UIColor(red: 255/255.0, green: 212/255.0, blue: 41/255.0, alpha: 1.0)

var NAV_BAR_TINT = UIColor(red: 88/255.0, green: 89/255.0, blue: 91/255.0, alpha: 1.0)
var NAV_BAR_BUTTON_TINT = UIColor(red: 88/255.0, green: 89/255.0, blue: 91/255.0, alpha: 1.0)
var BACKGROUND_COLOR = UIColor(red: 241/255.0, green: 242/255.0, blue: 242/255.0, alpha: 1.0)
var TEXT_BORDER_COLOR = UIColor(red: 108/255.0, green: 114/255.0, blue: 127/255.0, alpha: 1.0)

var ACDLogoutNotification = "ACDLogoutNotification"
var ACDRefreshNotification = "ACDRefreshNotification"
