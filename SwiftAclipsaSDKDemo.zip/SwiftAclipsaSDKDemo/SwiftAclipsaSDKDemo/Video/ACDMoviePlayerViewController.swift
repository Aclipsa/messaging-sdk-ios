//
//  ACDMoviePlayerViewController.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit
import MediaPlayer

class ACDMoviePlayerViewController : MPMoviePlayerViewController
{
    override func shouldAutorotate() -> Bool
    {
        if self.moviePlayer.naturalSize.width >= 480
        {
            if UIDevice.currentDevice().orientation == UIDeviceOrientation.Portrait
            {
                self.moviePlayer.scalingMode = MPMovieScalingMode.AspectFit
            }
            else
            {
                self.moviePlayer.scalingMode = MPMovieScalingMode.AspectFill
            }
        }
        else
        {
            if UIDevice.currentDevice().orientation == UIDeviceOrientation.Portrait
            {
                self.moviePlayer.scalingMode = MPMovieScalingMode.AspectFill
            }
            else
            {
                self.moviePlayer.scalingMode = MPMovieScalingMode.AspectFit
            }
        }
        
        return true
    }
}
