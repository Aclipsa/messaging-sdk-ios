//
//  ACDVideoListViewController.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit
import AclipsaSDK

class ACDVideoListViewController: UITableViewController
{
    var videos = [AnyObject]()
    
    override func viewWillAppear(animated: Bool)
    {
        super.viewWillAppear(animated)
        
        // Use the SDK to load the videos available for a user.
        if ACLIPSession.activeSession().userID != nil
        {
            ACLIPSession.activeSession().loadUserVideosWithCompletionBlock({(results: AnyObject?) in
                self.videos = results as! [ACLIPVideo]
                self.tableView.reloadData()
                },
                errorBlock: {(error: NSError!) in
                    NSLog("An error occured while loading videos: %@", error)
            })
        }
    }
    
    // MARK: Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1;
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.videos.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell: ACDVideoListCell = tableView.dequeueReusableCellWithIdentifier("VideoListCell") as! ACDVideoListCell
        
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        
        let video: ACLIPVideo = self.videos[indexPath.row] as! ACLIPVideo
        let placeHolder: UIImage = UIImage(named: "loading")!
        
        cell.titleLabel?.text = video.title
        cell.videoImageView?.setImageWithVideo(video, placeholderImage: placeHolder)
        
        return cell
    }
    
    // MARK: Table view Delegate
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        return 44.0
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        let video: ACLIPVideo = self.videos[indexPath.row] as! ACLIPVideo
        
        // Use the SDK to reload a video before trying to view it. This ensures the video is still available to the recipient.
        ACLIPSession.activeSession().loadUserVideoWithID(video.guid, completionBlock: {(aclipVideo: AnyObject?) in
            if aclipVideo != nil
            {
                let controller: ACLIPMoviePlayerViewController = ACLIPMoviePlayerViewController(forVideo: video)
                self.presentMoviePlayerViewControllerAnimated(controller)
            }
            },
            errorBlock:nil)
    }
    
    // MARK: Refresh
    
    @IBAction func refreshVideos(sender: AnyObject?)
    {
        // Use the SDK to load the videos available for a user.
        ACLIPSession.activeSession().loadUserVideosWithCompletionBlock({(results: AnyObject?) in
            self.videos = results as! [ACLIPVideo]
            self.tableView.reloadData()
            },
            errorBlock: {(error: NSError!) in
                NSLog("An error occured while loading videos: %@", error)
        })
    }
}
