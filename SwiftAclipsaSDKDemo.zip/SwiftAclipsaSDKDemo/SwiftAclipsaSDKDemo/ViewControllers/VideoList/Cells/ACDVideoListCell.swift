//
//  ACDVideoListCell.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit

class ACDVideoListCell: UITableViewCell
{
    @IBOutlet weak var titleLabel: UILabel?;
    @IBOutlet weak var videoImageView: UIImageView?;
}
