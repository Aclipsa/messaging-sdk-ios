//
//  ACDDetailViewController.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/7/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit
import AclipsaSDK

class ACDDetailViewController : UIViewController, ACDRecordViewControllerDelegate, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var scrollView: UIScrollView?
    @IBOutlet weak var contentView: UIView?
    @IBOutlet weak var thumbnailImageView: UIImageView?
    @IBOutlet weak var playButton: UIButton?
    @IBOutlet weak var titleLabel: UILabel?
    @IBOutlet weak var dateLabel: UILabel?
    @IBOutlet weak var descriptionLabel: UILabel?
    @IBOutlet weak var fromLabel: UILabel?
    @IBOutlet weak var fromTitleLabel: UILabel?
    @IBOutlet weak var toTitleLabel: UILabel?
    @IBOutlet weak var yankButton: UIButton?
    @IBOutlet weak var deleteButton: UIButton?
    @IBOutlet weak var forwardButton: UIButton?
    @IBOutlet weak var replyButton: UIButton?
    @IBOutlet weak var nameTableView: UITableView?
    @IBOutlet weak var yankedImageView: UIImageView?
    @IBOutlet weak var videoView: UIView?
    
    @IBOutlet weak var tableHeightConstraint: NSLayoutConstraint?
    @IBOutlet weak var contentViewHeightConstraint: NSLayoutConstraint?
    
    var message: ACLIPMessage?
    var PADDING: CGFloat = 8
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.title = self.message?.sender.userID
        
        let placeholder: UIImage! = UIImage(named: "loading")
        self.thumbnailImageView?.setImageWithVideo(self.message?.video, placeholderImage: placeholder)
        
        self.titleLabel?.text = self.message?.title
        self.descriptionLabel?.text = self.message?.messageText
        self.fromLabel?.text = self.message?.sender.userID
        
        if self.message?.messageText == nil || self.message?.title == ""
        {
            self.descriptionLabel?.hidden = true
        }
        
        if self.message?.title == nil || self.message?.title == ""
        {
            self.titleLabel?.hidden = true
        }
        
        let formatter: NSDateFormatter = {
            let dateFormatter = NSDateFormatter()
            dateFormatter.AMSymbol = "AM"
            dateFormatter.PMSymbol = "PM"
            dateFormatter.dateFormat = "MM/dd/yyyy hh:mm a"
            dateFormatter.timeZone = NSTimeZone.localTimeZone()
            return dateFormatter
        }()
        
        self.dateLabel?.text = formatter.stringFromDate(self.message!.createdDate)
        
        if self.message?.sender.userID == ACLIPSession.activeSession().userID
        {
            self.yankedImageView?.hidden = self.message?.yanked == true ? false : true
            self.forwardButton?.hidden = false
            self.yankButton?.hidden = false
        }
        else
        {
            self.forwardButton?.hidden = true
            self.yankButton?.hidden = true
        }
        
        if self.message?.read == false
        {
            self.message?.markMessageReadCompleteBlock(nil, errorBlock: {(error: NSError!) in
                NSLog("An error occured while marking message read: %@", error);
            })
        }
    }
    
    override func viewDidLayoutSubviews()
    {
        self.tableHeightConstraint?.constant = self.calculateTableSize().height
        self.contentViewHeightConstraint?.constant = self.nameTableView!.frame.origin.y + self.tableHeightConstraint!.constant + PADDING
        
        self.scrollView?.contentSize = self.contentView!.frame.size
    }
    
    func popIfNeeded()
    {
        let userInfo: [NSObject : AnyObject]! = NSDictionary(object: self.message!, forKey: "message") as [NSObject : AnyObject]
        NSNotificationCenter.defaultCenter().postNotificationName(ACDRefreshNotification, object: nil, userInfo: userInfo)
        
        let alert: UIAlertView = UIAlertView(title: NSLocalizedString("Message Not Available", comment: ""), message: NSLocalizedString("The message is no longer available.", comment: ""), delegate: self, cancelButtonTitle: NSLocalizedString("OK", comment: ""))
        alert.show()
        
        if self.message?.messageThread.messages.count > 1
        {
            self.navigationController?.popViewControllerAnimated(true)
        }
        else
        {
            self.navigationController?.popToRootViewControllerAnimated(true)
        }
    }
    
    // MARK: IBActions
    
    @IBAction func playButtonTapped(sender: UIButton?)
    {
        // Use the SDK to reload a message before trying to view it. This ensures the message is still available to the recipient.
        ACLIPSession.activeSession().loadMessageWithGUID(self.message?.guid, completeBlock: {(aclipMessage: AnyObject?) in
            if aclipMessage != nil
            {
                if let message = aclipMessage as? ACLIPMessage
                {
                    self.message = message
                    let controller: ACLIPMoviePlayerViewController! = ACLIPMoviePlayerViewController(forMessage: self.message)
                    self.presentMoviePlayerViewControllerAnimated(controller)
                }
                else
                {
                    self.popIfNeeded()
                }
            }
        }, errorBlock:nil)
    }
    
    @IBAction func yankTapped(sender: UIButton?)
    {
        let recipients = Array(self.message!.recipients)
        
        if self.message?.yanked == true
        {
            self.message?.unyankMessageForRecipients(recipients, completeBlock: {(results: AnyObject!) in
                    self.yankedImageView?.hidden = true
                }, errorBlock: {(error: NSError!) in
                    NSLog("An error occured while unyanking message: %@", error);
            })
        }
        else
        {
            // Use the SDK to "yank" a message from recipients. This makes recipients unable to view the message.
            self.message?.yankMessageForRecipients(recipients, completeBlock: {(results: AnyObject!) in
                self.yankedImageView?.hidden = false
                }, errorBlock: {(error: NSError!) in
                    NSLog("An error occured while yanking message: %@", error);
            })
        }
    }
    
    @IBAction func deleteTapped(sender: UIButton?)
    {
        self.message?.deleteMessageCompleteBlock({(results: AnyObject?) in
            let userInfo: [NSObject : AnyObject]! = NSDictionary(object: self.message!, forKey: "message") as [NSObject : AnyObject]
            NSNotificationCenter.defaultCenter().postNotificationName(ACDRefreshNotification, object: nil, userInfo: userInfo)
            
            if self.message?.messageThread.messages.count > 1
            {
                self.navigationController?.popViewControllerAnimated(true)
            }
            else
            {
                self.navigationController?.popToRootViewControllerAnimated(true)
            }
            
            self.message = nil
            
            }, errorBlock: {(error: NSError!) in
                NSLog("An error occured while deleting message: %@", error);
        })
    }
    
    @IBAction func replyTapped(sender: UIButton?)
    {
        let recordViewController: ACDRecordViewController! = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("RecordViewController") as! ACDRecordViewController
        recordViewController.delegate = self
        
        self.presentViewController(recordViewController, animated: true, completion: nil)
    }
    
    @IBAction func forwardTapped(sender: UIButton?)
    {
        let sendMessageController: ACDSendMessageViewController! = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("SendMessageViewController") as! ACDSendMessageViewController
        sendMessageController.forwardingMessage = self.message
        
        self.presentViewController(sendMessageController, animated: true, completion: nil)
    }
    
    // MARK: ACDRecordViewControllerDelegate
    
    func finishedRecordingURL(videoURL: NSURL, thumbnailImage: UIImage)
    {
        self.dismissViewControllerAnimated(false, completion: {
            let sendMessageController: ACDSendMessageViewController! = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("SendMessageViewController") as! ACDSendMessageViewController
            sendMessageController.videoURL = videoURL
            sendMessageController.thumbnailImage = thumbnailImage
            
            var recipients = Array(self.message!.recipients)
            
            if self.message?.sender != ACLIPUser.me()
            {
                recipients.removeObject(ACLIPUser.me())
                recipients.append(self.message!.sender)
            }
            
            sendMessageController.recipientList = self.stringFromUserList(recipients)
            
            self.presentViewController(sendMessageController, animated: true, completion: nil)
        })
    }
    
    // MARK: TableView
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        let recipients = Array(self.message!.recipients)
        let count: Bool = (recipients.count >= indexPath.row) == true
        let index: Bool = (self.message?.recipients.count > 0) == true
        var person: ACLIPUser? = nil
        var messageStatus: ACLIPMessageStatus? = nil
        
        if count && index
        {
            person = recipients[indexPath.row] as? ACLIPUser
        }
        
        if person != nil
        {
            messageStatus = ACLIPMessageStatus(forUser: person?.userID, messageGuid: self.message?.guid)
        }
        
        if (self.message?.sender == ACLIPUser.me() && messageStatus != nil && messageStatus?.screenshotDate != nil)
        {
            return 65
        }
        else if self.message?.sender == ACLIPUser.me()
        {
            return 44
        }
        
        return 21
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if self.message != nil
        {
            return self.message!.recipients.count
        }
        
        return 0
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell: ACDNameCell! = tableView.dequeueReusableCellWithIdentifier("NameCell") as! ACDNameCell
        
        let recipients = Array(self.message!.recipients)
        let person: ACLIPUser! = recipients[indexPath.row] as! ACLIPUser
        
        if person == ACLIPUser.me()
        {
            cell.nameLabel?.text = NSLocalizedString("Me", comment: "")
            cell.nameLabel?.hidden = false
        }
        else
        {
            cell.nameLabel?.text = person.userID
            cell.nameLabel?.hidden = false
        }
        
        cell.watchedLabel?.hidden = true
        cell.screenshottedLabel?.hidden = true
        cell.screenshotImageView?.hidden = true
        
        if self.message?.sender == ACLIPUser.me()
        {
            let messageStatus: ACLIPMessageStatus? = ACLIPMessageStatus(forUser: person.userID, messageGuid: ACLIPMessage(forGUID: self.message!.guid).guid)
            
            if messageStatus != nil
            {
                if messageStatus?.messageRead == true
                {
                    cell.readImageView?.image = UIImage(named: "WatchedIcon")
                    cell.watchedLabel?.text = NSLocalizedString("Viewed", comment: "")
                }
                else
                {
                    cell.readImageView?.image = UIImage(named: "UnwatchedIcon")
                    cell.watchedLabel?.text = NSLocalizedString("Unviewed", comment: "")
                }
                
                if messageStatus?.screenshotDate != nil
                {
                    cell.screenshottedLabel?.hidden = false
                    cell.screenshotImageView?.image = UIImage(named: "ScreenshotTakenIcon")
                    cell.screenshotImageView?.hidden = false
                }
                else
                {
                    cell.screenshottedLabel?.hidden = true
                    cell.screenshotImageView?.hidden = true
                }
                
                cell.watchedLabel?.hidden = false
            }
        }
        
        return cell
    }
    
    // MARK: Helpers
    
    func calculateTableSize() -> CGSize
    {
        var height: CGFloat = 0.0
        
        if (self.message != nil)
        {
            for index in 0...self.message!.recipients.count-1
            {
                height += self.tableView(self.nameTableView!, heightForRowAtIndexPath: NSIndexPath(forRow: index, inSection: 0))
            }
        }
        
        return CGSizeMake(self.nameTableView!.frame.size.width, height)
    }
    
    func stringFromUserList(userList: [NSObject]) -> String
    {
        if userList.count > 0
        {
            let IDArray: Array = (userList as NSArray).valueForKey("userID") as! [AnyObject]
            return (IDArray as NSArray).componentsJoinedByString(", ")
        }
        
        return ""
    }
}
