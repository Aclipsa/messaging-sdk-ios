//
//  ACDNameCell.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/7/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation

class ACDNameCell: UITableViewCell
{
    @IBOutlet weak var readImageView: UIImageView?
    @IBOutlet weak var screenshotImageView: UIImageView?
    @IBOutlet weak var nameLabel: UILabel?
    @IBOutlet weak var watchedLabel: UILabel?
    @IBOutlet weak var screenshottedLabel: UILabel?
}
