//
//  ACDLoginViewController.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit


class ACDLoginViewController : UIViewController
{
    @IBOutlet weak var userIDTextField: UITextField?
    @IBOutlet weak var loginButton: UIButton?
    
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!)
    {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        
        self.title = NSLocalizedString("Login", comment: "")
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        if self.respondsToSelector(Selector("edgesForExtendedLayout"))
        {
            self.edgesForExtendedLayout = UIRectEdge.None
        }
        
        self.userIDTextField?.layer.borderWidth = 1.0
        self.userIDTextField?.layer.cornerRadius = 10.0
        self.userIDTextField?.layer.borderColor = UIColor.lightGrayColor().CGColor
        
        self.userIDTextField?.text = ""
    }
    
    @IBAction func loginButtonPushed(sender: UIButton?)
    {
        if self.userIDTextField?.text != "" && self.userIDTextField?.text != nil
        {
            ACLIPSession.activeSession().loginWithUserID(self.userIDTextField?.text, completionBlock: {(results: AnyObject!) in
                self.dismissViewControllerAnimated(true, completion: nil)
                },
                errorBlock: {(error: NSError!) in
                    NSLog("An error occured while logging in: %@", error)
            })
        }
    }
}
