//
//  ACDUploadVideoController.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit
import MobileCoreServices


class ACDUploadVideoController : UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate
{
    @IBOutlet weak var selectButton: UIButton?
    @IBOutlet weak var uploadButton: UIButton?
    @IBOutlet weak var titleTextField: UITextField?
    @IBOutlet weak var progressLabel: UILabel?
    @IBOutlet weak var encryptedSwitch: UISwitch?
    @IBOutlet weak var scrollView: UIScrollView?
    @IBOutlet weak var contentView: UIView?
    
    var uploadingVideo: ACLIPVideo?
    var videoPicker: UIImagePickerController?
    var videoInfo: NSDictionary?
    var isKeyboardShowing: Bool = false
    var savedScrollViewHeight: CGFloat = 0.0
    var keyboardTopPosition: CGFloat = 0.0
    
    deinit
    {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillShow:"), name: UIKeyboardWillShowNotification, object: self.view.window)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillHide:"), name: UIKeyboardWillHideNotification, object: self.view.window)
    }
    
    override func viewDidAppear(animated: Bool)
    {
        let width = self.contentView?.frame.width
        let height = self.contentView?.frame.height
        
        self.scrollView?.contentSize = CGSizeMake(width!, height!)
        
        super.viewDidAppear(animated)
    }
    
    // MARK: KVO
    
    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>)
    {
        if let obj = object
        {
            if keyPath == "state"
            {
                switch (obj.state as ACLIPVideoStateType)
                {
                case ACLIPVideoStateType.CompressingState:
                    self.progressLabel?.text = "Compressing Video"
                    break;
                    
                case ACLIPVideoStateType.UploadingState:
                    self.progressLabel?.text = "Uploaded: 0%%"
                    break;
                    
                case ACLIPVideoStateType.ProcessingState:
                    let title = uploadingVideo?.title
                    self.progressLabel?.text = String(format: "Processing Video: %@", title!)
                    self.uploadButton?.enabled = false
                    self.selectButton?.setTitle("Select Video", forState: UIControlState.Normal)
                    self.titleTextField?.text = ""
                    break;
                    
                case ACLIPVideoStateType.CompletedState:
                    self.progressLabel?.text = "Video Done"
                    break;
                    
                default:
                    self.progressLabel?.text = ""
                }
            }
            else if keyPath == "uploadProgress"
            {
                let progress = obj.uploadProgress * 100
                progressLabel?.text = String(format: "Uploaded: %.2f%%", progress)
            }
            else
            {
                super.observeValueForKeyPath(keyPath, ofObject: object, change: change, context: context)
            }
        }
    }
    
    // MARK: Actions
    
    @IBAction func selectVideoPressed(sender: UIButton?)
    {
        self.videoPicker = UIImagePickerController()
        videoPicker?.delegate = self
        videoPicker?.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
        videoPicker?.mediaTypes = [kUTTypeMovie as String]
        
        self.presentViewController(self.videoPicker!, animated: true, completion: nil)
    }
    
    @IBAction func uploadVideoPressed(sender: UIButton?)
    {
        self.titleTextField?.resignFirstResponder()
        let encrypted = self.encryptedSwitch?.on
        
        // Use the SDK to upload a video. By default, these videos can be viewed by any user.
        let video: ACLIPVideo = ACLIPSession.activeSession().uploadVideoAtURL(self.videoInfo?.objectForKey(UIImagePickerControllerMediaURL) as! NSURL, title: self.titleTextField?.text, attributes: nil, skipEncoding: !encrypted!, completeBlock: nil, errorBlock: {(error: NSError!) in
            NSLog("An error occured while uploading: %@", error);
        })
        
        self.uploadingVideo = video
        self.uploadingVideo!.addObserver(self, forKeyPath: "state", options: NSKeyValueObservingOptions.New, context: nil)
        self.uploadingVideo!.addObserver(self, forKeyPath: "uploadProgress", options: NSKeyValueObservingOptions.New, context: nil)
    }
    
    // MARK: UITextFieldDelegate
    
    func textFieldShouldReturn(textField: UITextField) -> Bool
    {
        if (self.titleTextField?.isFirstResponder() != nil)
        {
            self.titleTextField?.resignFirstResponder()
        }
        
        return true
    }
    
    // MARK: UIImagePickerControllerDelegate delegate
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject])
    {
        let ref: NSURL = info[UIImagePickerControllerReferenceURL] as! NSURL
        
        self.videoInfo = info
        self.dismissViewControllerAnimated(true, completion: nil)
        self.uploadButton?.enabled = true
        self.selectButton?.setTitle(ref.lastPathComponent, forState: UIControlState.Normal)
        self.titleTextField?.text = ref.lastPathComponent
        self.videoPicker = nil
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController)
    {
        self.dismissViewControllerAnimated(true, completion: nil)
        self.videoPicker = nil
    }
    
    // MARK: UIKeyboard Notifications
    
    func keyboardWillShow(aNotification: NSNotification)
    {
        let info: NSDictionary = aNotification.userInfo!
        let kbSize: CGSize = info[UIKeyboardFrameBeginUserInfoKey]!.CGRectValue.size
        let top = self.scrollView?.contentOffset.y
        let contentInsets: UIEdgeInsets = UIEdgeInsets(top: 0 - top!, left: 0.0, bottom: kbSize.height, right: 0.0)
        
        self.scrollView?.contentInset = contentInsets
        self.scrollView?.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillHide(aNotification: NSNotification)
    {
        let contentInsets: UIEdgeInsets = UIEdgeInsetsZero
        self.scrollView?.contentInset = contentInsets
        self.scrollView?.scrollIndicatorInsets = contentInsets
    }
}
