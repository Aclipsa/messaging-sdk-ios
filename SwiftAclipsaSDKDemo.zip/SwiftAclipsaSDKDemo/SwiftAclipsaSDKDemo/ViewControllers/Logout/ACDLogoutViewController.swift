//
//  ACDLogoutViewController.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit


class ACDLogoutViewController: UIViewController
{
    @IBOutlet weak var userIDLabel: UILabel?
    @IBOutlet weak var logoutButton: UIButton?
    @IBOutlet weak var deleteAccountButton: UIButton?
    
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!)
    {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        
        self.title = NSLocalizedString("Log Out", comment: "")
        self.tabBarItem.image = UIImage(named: "Logout")
    }

    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        if self.respondsToSelector(Selector("edgesForExtendedLayout"))
        {
            self.edgesForExtendedLayout = UIRectEdge.Bottom
        }
    }
    
    override func viewWillAppear(animated: Bool)
    {
        super.viewWillAppear(animated)
        
        self.userIDLabel?.text = ACLIPSession.activeSession().userID
    }
    
    @IBAction func logoutButtonPushed(sender: UIButton?)
    {
        // Log out of the SDK. Videos cannot be viewed and messages cannot be sent
        ACLIPSession.activeSession().logoutWithCompletionBlock({(results: AnyObject!) in
            self.userIDLabel?.text = ""
            
            let appDelegate: ACDAppDelegate = UIApplication.sharedApplication().delegate as! ACDAppDelegate
            appDelegate.showLogin(true)
            appDelegate.tabBarController?.selectedIndex = 0
            
            NSNotificationCenter.defaultCenter().postNotificationName(ACDLogoutNotification, object: nil)
            
            }, errorBlock: {(error: NSError!) in
                NSLog("An error occured while logging out: %@", error);
        })
    }
    
    @IBAction func deleteAccountPushed(sender: UIButton?)
    {
        ACLIPSession.activeSession().deleteUserWithID(ACLIPSession.activeSession().userID, completionBlock: {(results: AnyObject!) in
            self.userIDLabel?.text = ""
            
            let appDelegate: ACDAppDelegate = UIApplication.sharedApplication().delegate as! ACDAppDelegate
            appDelegate.showLogin(true)
            appDelegate.tabBarController?.selectedIndex = 0
            
            NSNotificationCenter.defaultCenter().postNotificationName(ACDLogoutNotification, object: nil)
            
            }, errorBlock: {(error: NSError!) in
                NSLog("An error occured while deleting user: %@", error);
        })
    }
}