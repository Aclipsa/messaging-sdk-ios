//
//  ACDConversationCell.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import AclipsaSDK

class ACDConversationCell : UITableViewCell
{
    @IBOutlet weak var usersLabel: UILabel?;
    @IBOutlet weak var dateLabel: UILabel?;
    
    func configureCellForMessageThread(messageThread: ACLIPMessageThread)
    {
        self.usersLabel?.text = messageThread.userListString()
        
        let instance: NSDateFormatter = {
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateFormat = "MM/dd/yyyy"
            dateFormatter.timeZone = NSTimeZone.localTimeZone()
            return dateFormatter
        }()
        
        self.dateLabel?.text = instance.stringFromDate(messageThread.sortedMessages.last!.createdDate)
    }
}
