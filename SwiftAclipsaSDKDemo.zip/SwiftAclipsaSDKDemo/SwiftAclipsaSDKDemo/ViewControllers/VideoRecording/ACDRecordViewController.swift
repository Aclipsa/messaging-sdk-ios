//
//  ACDRecordViewController.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit

protocol ACDRecordViewControllerDelegate
{
    func finishedRecordingURL(videoURL: NSURL, thumbnailImage: UIImage)
}

class ACDRecordViewController : UIViewController, UIVideoEditorControllerDelegate, UINavigationControllerDelegate, AVCamCaptureManagerDelegate, UIAlertViewDelegate
{
    @IBOutlet weak var overlayView: UIView?
    @IBOutlet weak var cameraView: UIView?
    @IBOutlet weak var flipButton: UIButton?
    @IBOutlet weak var torchButton: UIButton?
    @IBOutlet weak var timerView: UIView?
    @IBOutlet weak var recordButtonImageView: UIImageView?
    
    var delegate: ACDRecordViewControllerDelegate? = nil
    var captureManager: AVCamCaptureManager? = nil
    var captureVideoPreviewLayer: AVCaptureVideoPreviewLayer? = nil
    var capturing: Bool = false
    var flashlightOn: Bool = false
    var movieURL: NSURL? = nil
    var timer: NSTimer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let manager: AVCamCaptureManager = AVCamCaptureManager()
        self.captureManager = manager
        
        self.captureManager?.delegate = self
        
        if (self.captureManager?.setupSession() == true)
        {
            let newCaptureVideoPreviewLayer: AVCaptureVideoPreviewLayer = AVCaptureVideoPreviewLayer(session: self.captureManager?.session)
            let view: UIView = self.cameraView!
            let viewLayer: CALayer = view.layer
            viewLayer.masksToBounds = true
            
            let bounds = viewLayer.bounds
            newCaptureVideoPreviewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
            newCaptureVideoPreviewLayer.bounds = bounds
            newCaptureVideoPreviewLayer.position = CGPoint(x: CGRectGetMidX(bounds), y: CGRectGetMidY(bounds))
            
            viewLayer.insertSublayer(newCaptureVideoPreviewLayer, atIndex: 0)
            
            self.captureVideoPreviewLayer = newCaptureVideoPreviewLayer
        }
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("sessionStartedRunning"), name: AVCaptureSessionDidStartRunningNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("sessionStoppedRunning"), name: AVCaptureSessionDidStopRunningNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("sessionError:"), name: AVCaptureSessionRuntimeErrorNotification, object: nil)
    }
    
    deinit
    {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    override func prefersStatusBarHidden() -> Bool
    {
        return true;
    }
    
    func sessionStartedRunning()
    {
        dispatch_async(dispatch_get_main_queue(), {
            if self.captureManager?.session.running == true
            {
                self.recordButtonImageView?.image = UIImage(named: "TabBarRecordButtonReady")
                self.timerView?.userInteractionEnabled = true
            }
        })
    }
    
    func sessionStoppedRunning()
    {
        if UIApplication.sharedApplication().applicationState == UIApplicationState.Active
        {
            self.startCamera()
        }
    }
    
    func sessionError(notif: NSNotification)
    {
        self.timerView?.userInteractionEnabled = true
        
        if UIApplication.sharedApplication().applicationState == UIApplicationState.Active
        {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), {
                self.captureManager?.session.stopRunning()
                self.startCamera()
            })
        }
    }
    
    override func viewWillAppear(animated: Bool)
    {
        super.viewWillAppear(animated)
        
        if self.spaceAvailable()
        {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), {
                self.captureManager?.session.startRunning()
            })
        }
        else {
            let alert: UIAlertView = UIAlertView(title: NSLocalizedString("Cannot Record Video", comment: ""), message: NSLocalizedString("There is not enough available storage to record video.", comment: ""), delegate: self, cancelButtonTitle: NSLocalizedString("OK", comment: ""))
            alert.show()
            
            self.timerView?.userInteractionEnabled = true
        }
        
        self.torchButton?.hidden = self.captureManager?.canUseFlashlight() == false
        self.flipButton?.hidden = self.captureManager?.canFlipCamera() == false
    }
    
    override func viewWillDisappear(animated: Bool)
    {
        super.viewWillDisappear(animated)
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), {
            self.captureManager?.session.stopRunning()
        })
    }
    
    override func viewDidDisappear(animated: Bool)
    {
        super.viewDidDisappear(animated)
        
        self.captureManager?.delegate = nil
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), {
            self.captureManager?.session.stopRunning()
        })
        
        if self.flashlightOn
        {
            self.flashlightOn = false
            self.torchButton?.setBackgroundImage(UIImage(named: "FlashOff"), forState: UIControlState.Normal)
        }
        
        self.timerView?.userInteractionEnabled = true
    }
    
    override func shouldAutorotate() -> Bool
    {
        return true;
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask
    {
        return UIInterfaceOrientationMask.AllButUpsideDown
    }
    
    // MARK: RecordingControllerDelegate methods
    
    func didSaveVideoToURL(inUrl: NSURL!)
    {
        self.movieURL = inUrl
        self.delegate?.finishedRecordingURL(self.movieURL!, thumbnailImage: UIImage.getThumbnailFromURL(self.movieURL, size: CGSize(width: 360.0, height: 360.0)))
    }
    
    func failedToSaveVideo()
    {
        UIApplication.sharedApplication().idleTimerDisabled = false
        
        self.capturing = false
        self.flipButton?.hidden = self.captureManager?.canFlipCamera() == false
        self.captureManager?.stopRecording()
        
        if self.flashlightOn
        {
            self.flashlightOn = false
            self.torchButton?.setBackgroundImage(UIImage(named: "FlashOff"), forState: UIControlState.Normal)
        }
    }
    
    func captureManagerDidToggleCamera(captureManager: AVCamCaptureManager!)
    {
        self.cameraFlip()
    }
    
    // MARK: Camera methods
    
    @IBAction func cameraTapped()
    {
        if !self.capturing
        {
            self.recordStart()
        }
        else
        {
            self.timerView?.userInteractionEnabled = false
            self.recordButtonImageView?.image = UIImage(named: "TabBarRecordButton")
            
            self.capturing = false
            self.flipButton?.hidden = self.captureManager?.canFlipCamera() == false
            self.captureManager?.stopRecording()
            
            UIApplication.sharedApplication().idleTimerDisabled = false
            
            if self.flashlightOn
            {
                self.flashlightOn = false
                self.torchButton?.setBackgroundImage(UIImage(named: "FlashOff"), forState: UIControlState.Normal)
            }
        }
    }
    
    @IBAction func flipButtonTapped(sender: UIButton?)
    {
        self.captureManager?.toggleCamera()
        
        self.torchButton?.hidden = self.captureManager?.canUseFlashlight() == false
        
        if self.flashlightOn
        {
            self.flashlightOn = false
            self.torchButton?.setBackgroundImage(UIImage(named: "FlashOff"), forState: UIControlState.Normal)
        }
    }
    
    @IBAction func torchButtonTapped(sender: UIButton?)
    {
        if self.flashlightOn
        {
            self.flashlightOn = false
            self.torchButton?.setBackgroundImage(UIImage(named: "FlashOff"), forState: UIControlState.Normal)
        }
        else
        {
            self.flashlightOn = true
            self.torchButton?.setBackgroundImage(UIImage(named: "FlashOn"), forState: UIControlState.Normal)
        }
        
        self.captureManager?.toggleFlashlight()
    }
    
    func recordStart()
    {
        self.capturing = true
        self.flipButton?.hidden = true
        
        self.recordButtonImageView?.image = UIImage(named: "TabBarRecordButton")
        
        self.captureManager?.startRecording()
        UIApplication.sharedApplication().idleTimerDisabled = true
    }
    
    func spaceAvailable() -> Bool
    {
        let fileManager: NSFileManager = NSFileManager.defaultManager()
        let path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString
        let fattr: NSDictionary = try! fileManager.attributesOfFileSystemForPath(path as String)
        let freeSize: Int = fattr[NSFileSystemFreeSize]!.integerValue
        
        return freeSize > MIN_FREE_DISK_SPACE
    }
    
    func startCamera()
    {
        if self.spaceAvailable()
        {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), {
                self.captureManager?.session.stopRunning()
            })
        }
        else
        {
            let alert: UIAlertView = UIAlertView(title: NSLocalizedString("Cannot Record Video", comment: ""), message: NSLocalizedString("There is not enough available storage to record video.", comment: ""), delegate: self, cancelButtonTitle: NSLocalizedString("OK", comment: ""))
            alert.show()
            
            self.timerView?.userInteractionEnabled = false
        }
    }
    
    func cameraFlip()
    {
        UIView.transitionWithView(self.view, duration: 0.5, options: UIViewAnimationOptions.TransitionFlipFromRight, animations: {}, completion: {(fininshed: Bool) in})
    }
}
