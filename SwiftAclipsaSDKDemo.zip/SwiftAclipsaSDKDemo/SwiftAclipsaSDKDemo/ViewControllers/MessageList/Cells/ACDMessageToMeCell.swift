//
//  ACDMessageToMeCell.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/6/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import AclipsaSDK

class ACDMessageToMeCell: UITableViewCell
{
    @IBOutlet weak var dateLabel: UILabel?
    @IBOutlet weak var senderLabel: UILabel?
    @IBOutlet weak var thumbnailImageView: UIImageView?
    @IBOutlet weak var messageReadView: UIView?
    
    func configureCellForMessage(message: ACLIPMessage)
    {
        let placeholder: UIImage! = UIImage(named: "loading")
        
        let instance: NSDateFormatter = {
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateFormat = "MM/dd/yyyy"
            dateFormatter.timeZone = NSTimeZone.localTimeZone()
            return dateFormatter
        }()
        
        self.dateLabel?.text = instance.stringFromDate(message.createdDate)
        
        self.senderLabel?.text = message.sender.userID
        self.thumbnailImageView?.setImageWithVideo(message.video, placeholderImage: placeholder)
        
        if message.read
        {
            self.messageReadView?.backgroundColor = UIColor.clearColor()
        }
        else
        {
            self.messageReadView?.backgroundColor = UIColor.greenColor()
        }
    }
}
