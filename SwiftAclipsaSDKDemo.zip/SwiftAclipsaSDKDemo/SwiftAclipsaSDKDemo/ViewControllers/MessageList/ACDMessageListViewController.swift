//
//  ACDMessageListViewController.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/6/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import AclipsaSDK

class ACDMessageListViewController : UITableViewController
{
    var messages = [ACLIPMessage]()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.title = NSLocalizedString("Messages", comment: "")
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("refreshMessages:"), name: ACDRefreshNotification, object: nil)
    }
    
    // MARK: TableView Data Source
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        return 60.0
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.messages.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var cell: ACDMessageToMeCell
        let message: ACLIPMessage! = self.messages[indexPath.row]
        
        if message.sender.userID == ACLIPSession.activeSession().userID
        {
            cell = tableView.dequeueReusableCellWithIdentifier("MessageFromMe") as! ACDMessageFromMeCell
        }
        else
        {
            cell = tableView.dequeueReusableCellWithIdentifier("MessageToMe") as! ACDMessageToMeCell
        }
        
        cell.configureCellForMessage(message)
        
        return cell
    }
    
    // MARK: TableView Delegate
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        let message: ACLIPMessage! = self.messages[indexPath.row]
        
        // Use the SDK to reload a message before trying to view it. This ensures the message is still available to the recipient.
        ACLIPSession.activeSession().loadMessageWithGUID(message.guid, completeBlock: {(aclipMessage: AnyObject?) in
                if aclipMessage != nil
                {
                    let detailViewController: ACDDetailViewController! = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("DetailViewController") as! ACDDetailViewController
                    detailViewController.message = message
                    
                    self.navigationController?.pushViewController(detailViewController, animated: true)
                    
                    tableView.deselectRowAtIndexPath(indexPath, animated: true)
                }
            }, errorBlock: {(error: NSError?) in
                let alert: UIAlertView = UIAlertView(title: NSLocalizedString("Message Not Available", comment: ""), message: NSLocalizedString("The message is no longer available.", comment: ""), delegate: self, cancelButtonTitle: NSLocalizedString("OK", comment: ""))
                alert.show()
                
                self.removeMessageAndRefresh(message)
        })
    }
    
    // MARK: Notification Handlers
    
    func refreshMessages(notif: NSNotification)
    {
        let info: NSDictionary = notif.userInfo!
        let messageToRemove: ACLIPMessage = info.objectForKey("message") as! ACLIPMessage
        
        self.removeMessageAndRefresh(messageToRemove)
    }
    
    func removeMessageAndRefresh(message: ACLIPMessage)
    {
        // Register with the SDK for message polling. SDK checks for messages every 30 seconds. Registering multiple times forces an immediate message poll.
        ACLIPSession.activeSession().registerMessageLoadingCompletionBlock(nil, errorBlock: {(error: NSError!) in
            NSLog("An error occured while loading messages: %@", error);
        })
        
        var messagesCopy = self.messages
        messagesCopy.removeObject(message)
        self.messages = messagesCopy
        
        if message.messageThread.messages.count > 0
        {
            self.tableView.reloadData()
        }
        else
        {
            self.navigationController?.popToRootViewControllerAnimated(true)
        }
    }
}
