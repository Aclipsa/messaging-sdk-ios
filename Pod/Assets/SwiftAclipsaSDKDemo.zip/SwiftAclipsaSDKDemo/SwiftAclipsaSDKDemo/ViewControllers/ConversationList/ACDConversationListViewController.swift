//
//  ACDConversationListViewController.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit


class ACDConversationListViewController : UITableViewController, ACDRecordViewControllerDelegate
{
    var messageThreads = [AnyObject]()
    
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!)
    {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        
        self.title = NSLocalizedString("Conversations", comment: "")
        self.tabBarItem.image = UIImage(named: "Conversations")
        self.tabBarItem.imageInsets = UIEdgeInsets(top: 5, left: 0, bottom: -5, right: 0)
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Refresh", style: UIBarButtonItemStyle.Plain, target: self, action: Selector("refreshVideos:"))
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Record", style: UIBarButtonItemStyle.Plain, target: self, action: Selector("recordMessage:"))
    }
    
    required init(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("logout"), name: ACDLogoutNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("refreshMessages"), name: ACDRefreshNotification, object: nil)
        
        // Register with the SDK for message polling. SDK checks for messages every 30 seconds
        ACLIPSession.activeSession().registerMessageLoadingCompletionBlock({(messages: [AnyObject]!, threads: [AnyObject]!) in
            var sortDescriptor: NSSortDescriptor = NSSortDescriptor(key: "lastMessage.createdDate", ascending: false)
            
            self.messageThreads = ((threads as NSArray).sortedArrayUsingDescriptors([sortDescriptor]) as? [ACLIPMessageThread])!
            self.tableView.reloadData()
            
            }, errorBlock: {(error: NSError!) in
                NSLog("An error occured while loading messages: %@", error);
        })
    }
    
    override func viewWillAppear(animated: Bool)
    {
        super.viewWillAppear(animated)
        
        // Register with the SDK for message polling. SDK checks for messages every 30 seconds. Registering multiple times forces an immediate message poll.
        ACLIPSession.activeSession().registerMessageLoadingCompletionBlock({(messages: [AnyObject]!, threads: [AnyObject]!) in
            var predicate: NSPredicate = NSPredicate(format: "messages.@count > 0")
            var sortDescriptor: NSSortDescriptor = NSSortDescriptor(key: "lastMessage.createdDate", ascending: false)
            
            self.messageThreads = (((threads as NSArray).filteredArrayUsingPredicate(predicate) as NSArray).sortedArrayUsingDescriptors([sortDescriptor]) as? [ACLIPMessageThread])!
            self.tableView.reloadData()
            
            }, errorBlock: {(error: NSError!) in
                NSLog("An error occured while loading messages: %@", error);
        })
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        if segue.identifier == "RecordVideo"
        {
            var recordViewController: ACDRecordViewController = segue.destinationViewController as! ACDRecordViewController
            recordViewController.delegate = self
        }
        else if segue.identifier == "MessageList"
        {
            var messageThread: ACLIPMessageThread = self.messageThreads[self.tableView.indexPathForSelectedRow()!.row] as! ACLIPMessageThread
            let messageListViewController: ACDMessageListViewController = segue.destinationViewController as! ACDMessageListViewController
            
            var sortDescriptor: NSSortDescriptor = NSSortDescriptor(key: "createdDate", ascending: false)
            var messagesArray = Array(messageThread.messages) as NSArray
            
            messageListViewController.messages = messagesArray.sortedArrayUsingDescriptors([sortDescriptor]) as! [ACLIPMessage]
            
            self.tableView.deselectRowAtIndexPath(self.tableView.indexPathForSelectedRow()!, animated: true)
        }
    }
    
    // MARK: Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.messageThreads.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var cell: ACDConversationCell = tableView.dequeueReusableCellWithIdentifier("ConversationCell") as! ACDConversationCell
        
        var messageThread: ACLIPMessageThread = self.messageThreads[indexPath.row] as! ACLIPMessageThread
        
        cell.configureCellForMessageThread(messageThread)
        
        return cell
    }
    
    // MARK: Table view Delegates
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        return 50.0
    }
    
    // MARK: ACDRecordViewControllerDelegate
    
    func finishedRecordingURL(videoURL: NSURL, thumbnailImage: UIImage)
    {
        self.dismissViewControllerAnimated(false, completion: {
            let sendMessageController: ACDSendMessageViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("SendMessageViewController") as! ACDSendMessageViewController
            sendMessageController.videoURL = videoURL
            sendMessageController.thumbnailImage = thumbnailImage
            
            self.presentViewController(sendMessageController, animated: true, completion: nil)
        })
    }
    
    // MARK: Notification Handler
    
    func logout()
    {
        self.navigationController?.popToRootViewControllerAnimated(false)
        self.messageThreads = [AnyObject]()
        self.tableView.reloadData()
    }
    
    func refreshMessages()
    {
        self.refreshMessages(nil)
    }
    
    // MARK: Refresh
    
    @IBAction func refreshMessages(sender: AnyObject?)
    {
        // Register with the SDK for message polling. SDK checks for messages every 30 seconds. Registering multiple times forces an immediate message poll.
        ACLIPSession.activeSession().registerMessageLoadingCompletionBlock({(messages: [AnyObject]!, threads: [AnyObject]!) in
            var predicate: NSPredicate = NSPredicate(format: "messages.@count > 0")
            var sortDescriptor: NSSortDescriptor = NSSortDescriptor(key: "lastMessage.createdDate", ascending: false)
            
            self.messageThreads = (((threads as NSArray).filteredArrayUsingPredicate(predicate) as NSArray).sortedArrayUsingDescriptors([sortDescriptor]) as? [ACLIPMessageThread])!
            self.tableView.reloadData()
            
            }, errorBlock: {(error: NSError!) in
                NSLog("An error occured while loading messages: %@", error);
        })
    }
}
