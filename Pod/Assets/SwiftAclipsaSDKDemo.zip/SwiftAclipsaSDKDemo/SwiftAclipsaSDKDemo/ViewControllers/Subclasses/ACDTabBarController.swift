//
//  ACDTabBarController.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit

class ACDTabBarController : UITabBarController
{
    override func supportedInterfaceOrientations() -> Int
    {
        return Int(UIInterfaceOrientationMask.Portrait.rawValue)
    }
    
    override func shouldAutorotate() -> Bool
    {
        return false
    }
}
