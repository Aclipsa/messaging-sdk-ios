//
//  ACDSendMessageViewController.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/6/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation
import UIKit


class ACDSendMessageViewController : UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate, UIVideoEditorControllerDelegate
{
    @IBOutlet weak var sendButton: UIButton?
    @IBOutlet weak var trimButton: UIButton?
    @IBOutlet weak var cancelButton: UIButton?
    @IBOutlet weak var playButton: UIButton?
    @IBOutlet weak var titleTextField: UITextField?
    @IBOutlet weak var descriptionTextView: UITextView?
    @IBOutlet weak var recipientsTextField: UITextField?
    @IBOutlet weak var progressLabel: UILabel?
    @IBOutlet weak var scrollView: UIScrollView?
    @IBOutlet weak var contentView: UIView?
    @IBOutlet weak var encryptedSwitch: UISwitch?
    @IBOutlet weak var thumbnailImageView: UIImageView?
    @IBOutlet weak var spinner: UIActivityIndicatorView?
    @IBOutlet weak var sendingSpinner: UIActivityIndicatorView?
    
    var uploadingVideo: ACLIPVideo?
    var videoURL: NSURL?
    var thumbnailImage: UIImage?
    var videoPlayback: ACDMoviePlayerViewController?
    var sentMessage: ACLIPMessage?
    var recipientList: String?
    var forwardingMessage: ACLIPMessage?
    var isKeyBoardShowing: Bool = false
    var savedScrollViewHeight: CGFloat = 0.0
    var keyboardTopPosition: CGFloat = 0.0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.sendButton?.enabled = true
        
        self.recipientsTextField?.layer.borderWidth = 1.0
        self.recipientsTextField?.layer.cornerRadius = 10.0
        self.recipientsTextField?.layer.borderColor = UIColor.lightGrayColor().CGColor
        
        self.titleTextField?.layer.borderWidth = 1.0
        self.titleTextField?.layer.cornerRadius = 10.0
        self.titleTextField?.layer.borderColor = UIColor.lightGrayColor().CGColor
        
        self.descriptionTextView?.layer.borderWidth = 1.0
        self.descriptionTextView?.layer.cornerRadius = 10.0
        self.descriptionTextView?.layer.borderColor = UIColor.lightGrayColor().CGColor
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillShow:"), name: UIKeyboardWillShowNotification, object: self.view.window)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillHide:"), name: UIKeyboardWillHideNotification, object: self.view.window)
    }
    
    deinit
    {
        NSNotificationCenter.defaultCenter().removeObserver(self)
        
        if self.sentMessage != nil
        {
            self.sentMessage?.video.removeObserver(self, forKeyPath: "state")
            self.sentMessage?.video.removeObserver(self, forKeyPath: "uploadProgress")
        }
    }
    
    override func viewWillAppear(animated: Bool)
    {
        super.viewWillAppear(animated)
        
        if self.recipientList != nil
        {
            self.recipientsTextField?.text = self.recipientList
        }
        
        if self.forwardingMessage != nil
        {
            self.titleTextField?.text = self.forwardingMessage?.title
            self.descriptionTextView?.text = self.forwardingMessage?.messageText
            self.trimButton?.hidden = true
            
            self.thumbnailImageView?.setImageWithURL(self.forwardingMessage?.video.thumbnailMediumURL, placeholderImage: UIImage(named: "loading"))
        }
        else
        {
            self.thumbnailImageView?.image = self.thumbnailImage
        }
    }
    
    override func viewDidAppear(animated: Bool)
    {
        var width = self.contentView?.frame.width
        var height = self.contentView?.frame.height
        
        self.scrollView?.contentSize = CGSizeMake(width!, height!)

        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool)
    {
        super.viewWillDisappear(animated)
        
        if self.videoPlayback?.moviePlayer.isPreparedToPlay == false
        {
            self.videoPlayback?.moviePlayer.stop()
            self.playButton?.userInteractionEnabled = true
            
            NSNotificationCenter.defaultCenter().removeObserver(self, name: MPMoviePlayerPlaybackDidFinishNotification, object: nil)
            NSNotificationCenter.defaultCenter().removeObserver(self, name: MPMediaPlaybackIsPreparedToPlayDidChangeNotification, object: nil)
        }
    }
    
    override func supportedInterfaceOrientations() -> Int
    {
        return Int(UIInterfaceOrientationMask.Portrait.rawValue)
    }
    
    // MARK: KVO
    
    override func observeValueForKeyPath(keyPath: String, ofObject object: AnyObject, change: [NSObject : AnyObject], context: UnsafeMutablePointer<Void>)
    {
        if keyPath == "state"
        {
            switch (object.state as ACLIPVideoStateType)
            {
            case ACLIPVideoStateType.CompressingState:
                self.progressLabel?.text = "Compressing Video"
                self.sendButton?.enabled = false
                break;
                
            case ACLIPVideoStateType.UploadingState:
                self.progressLabel?.text = "Uploaded: 0%%"
                self.sendButton?.enabled = false
                break;
                
            case ACLIPVideoStateType.ProcessingState:
                self.progressLabel?.text = String(format: "Processing Video")
                self.sendButton?.enabled = false
                self.titleTextField?.text = ""
                break;
                
            case ACLIPVideoStateType.CompletedState:
                self.progressLabel?.text = "Video Done"
                self.sendingSpinner?.stopAnimating()
                self.cancel()
                break;
                
            default:
                self.progressLabel?.text = ""
            }
        }
        else if keyPath == "uploadProgress"
        {
            var progress = object.uploadProgress * 100
            progressLabel?.text = String(format: "Uploaded: %.2f%%", progress)
        }
        else
        {
            super.observeValueForKeyPath(keyPath, ofObject: object, change: change, context: context)
        }
    }
    
    func cancel()
    {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    // MARK: Actions
    
    @IBAction func trimVideoPressed(sender: UIButton?)
    {
        let path: String? = self.videoURL?.path
        
        if UIVideoEditorController.canEditVideoAtPath(path!) == true
        {
            let videoEditor: ACDVideoEditorController = ACDVideoEditorController()
            let path: String! = self.videoURL?.path
            
            videoEditor.delegate = self
            videoEditor.videoPath = path
            
            self.presentViewController(videoEditor, animated: true, completion: nil)
        }
    }
    
    @IBAction func cancelPressed(sender: UIButton?)
    {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func uploadVideoPressed(sender: UIButton?)
    {
        if self.recipientsTextField?.text != "" && recipientsTextField?.text != nil
        {
            if self.recipientsTextField?.isFirstResponder() == true
            {
                self.titleTextField?.resignFirstResponder()
            }
            else if self.titleTextField?.isFirstResponder() == true
            {
                self.descriptionTextView?.resignFirstResponder()
            }
            else if self.titleTextField?.isFirstResponder() == true
            {
                self.titleTextField?.resignFirstResponder()
            }
            
            if self.forwardingMessage != nil
            {
                // Use the SDK to forward a message to recipients. Only the sender of a message is allowed to forward it.
                ACLIPSession.activeSession().forwardMessage(self.titleTextField?.text, messageText: self.descriptionTextView?.text, recipients: self.arrayFromRecipientsString(), video: self.forwardingMessage?.video, oldMessageGuid: self.forwardingMessage?.guid, newMessageGuid: nil, completeBlock: {(results: AnyObject!) in
                        self.cancel()
                    }, errorBlock: {(error: NSError!) in
                        self.sendingSpinner?.stopAnimating()
                        NSLog("An error occured while sending message: %@", error);
                })
            }
            else
            {
                let encrypted: Bool! = self.encryptedSwitch?.on
                
                // Use the SDK to send a message to recipients with an optional title and description.
                self.sentMessage = ACLIPSession.activeSession().sendMessage(self.titleTextField?.text, messageText: self.descriptionTextView?.text, recipients: self.arrayFromRecipientsString(), videoURL: self.videoURL, skipEncoding: !encrypted, attributes: [:], completeBlock: nil, errorBlock: {(error: NSError!) in
                    self.sendingSpinner?.stopAnimating()
                    NSLog("An error occured while sending message: %@", error);
                })
                
                self.sendingSpinner?.startAnimating()
                self.uploadingVideo = self.sentMessage?.video
                self.sentMessage?.video.addObserver(self, forKeyPath: "state", options: NSKeyValueObservingOptions.New, context: nil)
                self.sentMessage?.video.addObserver(self, forKeyPath: "uploadProgress", options: NSKeyValueObservingOptions.New, context: nil)
            }
        }
    }
    
    @IBAction func playVideoPressed(sender: UIButton?)
    {
        if self.forwardingMessage != nil
        {
            let controller: ACLIPMoviePlayerViewController = ACLIPMoviePlayerViewController(forVideo: self.forwardingMessage?.video)
            self.presentMoviePlayerViewControllerAnimated(controller)
        }
        else
        {
            self.videoPlayback = ACDMoviePlayerViewController(contentURL: self.videoURL)
            
            NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("playbackIsPreparedToPlayDidChange:"), name: MPMediaPlaybackIsPreparedToPlayDidChangeNotification, object: nil)
            NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("moviePlaybackDidFinish:"), name: MPMoviePlayerPlaybackDidFinishNotification, object: nil)
            
            var error: NSError? = nil
            AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback, error: &error)
            
            self.spinner?.startAnimating()
            self.playButton?.userInteractionEnabled = false
            
            self.videoPlayback?.moviePlayer.prepareToPlay()
        }
    }
    
    // MARK: Video Editing
    
    func videoEditorController(editor: UIVideoEditorController, didSaveEditedVideoToPath editedVideoPath: String)
    {
        let path: String = editedVideoPath.stringByReplacingOccurrencesOfString("//", withString: "/")
        
        self.videoURL = NSURL(fileURLWithPath: path)
        
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func videoEditorController(editor: UIVideoEditorController, didFailWithError error: NSError)
    {
        let alert: UIAlertView = UIAlertView(title: NSLocalizedString("Video Editing Error", comment: ""), message: error.localizedDescription, delegate: self, cancelButtonTitle: NSLocalizedString("OK", comment: ""))
        alert.show()
        
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func videoEditorControllerDidCancel(editor: UIVideoEditorController)
    {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    // MARK: Helpers
    
    func arrayFromRecipientsString() -> [String]
    {
        let text = self.recipientsTextField?.text
        var trimmedString: String = text!.stringByReplacingOccurrencesOfString(" ", withString: "")
        
        return trimmedString.componentsSeparatedByString(",")
    }
    
    // MARK: UITextFieldDelegate
    
    func textFieldShouldReturn(textField: UITextField) -> Bool
    {
        if self.recipientsTextField?.isFirstResponder() == true
        {
            self.titleTextField?.becomeFirstResponder()
            return true
        }
        else if self.titleTextField?.isFirstResponder() == true
        {
            self.descriptionTextView?.becomeFirstResponder()
            return false
        }
        
        return true
    }
    
    // MARK: Video Playback
    
    func playbackIsPreparedToPlayDidChange(inNotification: NSNotification)
    {
        if self.videoPlayback?.moviePlayer.isPreparedToPlay == true
        {
            if self.presentedViewController != self.videoPlayback
            {
                self.presentMoviePlayerViewControllerAnimated(self.videoPlayback)
            }
        }
    }
    
    func moviePlaybackDidFinish(inNotification: NSNotification)
    {
        self.spinner?.stopAnimating()
        self.videoPlayback?.moviePlayer.stop()
        self.videoPlayback = nil
        
        NSNotificationCenter.defaultCenter().removeObserver(self, name: MPMoviePlayerPlaybackDidFinishNotification, object: nil)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: MPMediaPlaybackIsPreparedToPlayDidChangeNotification, object: nil)
        
        self.playButton?.userInteractionEnabled = true
    }
    
    // MARK: UIKeyboard Notifications
    
    func keyboardWillShow(aNotification: NSNotification)
    {
        var info: NSDictionary = aNotification.userInfo!
        var kbSize: CGSize = info[UIKeyboardFrameBeginUserInfoKey]!.CGRectValue().size
        var top = self.scrollView?.contentOffset.y
        var contentInsets: UIEdgeInsets = UIEdgeInsets(top: 0 - top!, left: 0.0, bottom: kbSize.height, right: 0.0)
        
        self.scrollView?.contentInset = contentInsets
        self.scrollView?.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillHide(aNotification: NSNotification)
    {
        let contentInsets: UIEdgeInsets = UIEdgeInsetsZero
        self.scrollView?.contentInset = contentInsets
        self.scrollView?.scrollIndicatorInsets = contentInsets
    }
}
