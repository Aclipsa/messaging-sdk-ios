//
//  NSString+ACDAdditions.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import Foundation

extension NSString
{
    class func stringWithUUID() -> String
    {
        let uuid: CFUUIDRef = CFUUIDCreate(kCFAllocatorDefault)
        let str: String = CFUUIDCreateString(kCFAllocatorDefault, uuid) as String
        
        return str
    }
}
