//
//  ACDAppDelegate.swift
//  SwiftAclipsaSDKDemo
//
//  Created by Kevin Macaulay on 5/5/15.
//  Copyright (c) 2015 Aclipsa. All rights reserved.
//

import UIKit


@UIApplicationMain
class ACDAppDelegate: UIResponder, UIApplicationDelegate, UITabBarControllerDelegate
{
    var window: UIWindow?
    var tabBarController: UITabBarController?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool
    {
        ACLIPSession.createSessionWithAppID(ACLIPSA_APP_ID, serverEnvironment: ACLIPServerEnvironment.ACLIPStagingServer)
        
        UINavigationBar.appearance().tintColor = NAV_BAR_TINT
        UIBarButtonItem.appearance().tintColor = NAV_BAR_BUTTON_TINT
        UIToolbar.appearance().tintColor = NAV_BAR_TINT
        
        self.tabBarController = self.window?.rootViewController as? UITabBarController
        
        self.window?.makeKeyAndVisible()
        
        self.showLogin(false)
        
        return true
    }
    
    func application(application: UIApplication, supportedInterfaceOrientationsForWindow window: UIWindow?) -> Int
    {
        return self.windowInterfaceOrientations(window)
    }
    
    func showLogin(animated: Bool)
    {
        let loginNavController: UINavigationController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("LoginNavigationController") as! UINavigationController
        self.tabBarController?.presentViewController(loginNavController, animated: animated, completion: nil)
    }

    func supportedInterfaceOrientations() -> Int
    {
        return Int(UIInterfaceOrientationMask.Portrait.rawValue)
    }

    // MARK: Helpers
    
    func windowInterfaceOrientations(window: UIWindow?) -> Int
    {
        if UIApplication.sharedApplication().applicationState == UIApplicationState.Active && window?.rootViewController is UITabBarController
        {
            let rootController = window!.rootViewController as! UITabBarController
            let moviePlayerIsPresented = rootController.selectedViewController?.presentedViewController is MPMoviePlayerViewController
            let moviePlayerIsPresentedModal = rootController.selectedViewController?.presentedViewController?.presentedViewController is MPMoviePlayerViewController
            let presented = moviePlayerIsPresented || moviePlayerIsPresentedModal
            
            return presented ? Int(UIInterfaceOrientationMask.AllButUpsideDown.rawValue) : Int(UIInterfaceOrientationMask.Portrait.rawValue)
        }
        
        return Int(UIInterfaceOrientationMask.Portrait.rawValue)
    }

}

