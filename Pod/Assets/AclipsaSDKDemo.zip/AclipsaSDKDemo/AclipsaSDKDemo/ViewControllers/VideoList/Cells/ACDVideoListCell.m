//
//  ACDVideoListCell.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDVideoListCell.h"
#import <AclipsaSDK/AclipsaSDK.h>

@implementation ACDVideoListCell

@end
