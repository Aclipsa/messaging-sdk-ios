//
//  ACDMessageListViewController.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ACDMessageToMeCell, ACDMessageFromMeCell;

@interface ACDMessageListViewController : UITableViewController

@property (strong, nonatomic) NSArray *messages;

@end
