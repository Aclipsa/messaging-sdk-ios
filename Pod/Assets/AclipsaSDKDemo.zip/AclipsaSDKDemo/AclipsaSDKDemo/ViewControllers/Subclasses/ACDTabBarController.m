//
//  ACDTabBarController.m
//  AclipsaSDKDemo
//
//  Created by Kevin Macaulay on 10/28/14.
//  Copyright (c) 2014 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDTabBarController.h"

@interface ACDTabBarController ()

@end

@implementation ACDTabBarController

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

-(BOOL)shouldAutoRotate
{
    return NO;
}

@end
