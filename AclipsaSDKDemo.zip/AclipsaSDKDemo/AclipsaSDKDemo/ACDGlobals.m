//
//  ACDGlobals.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDGlobals.h"

@implementation ACDGlobals

@end
