//
//  ACDAppDelegate.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDAppDelegate.h"
#import <AclipsaSDK/AclipsaSDK.h>
#import "ACDVideoListViewController.h"
#import "ACDUploadVideoController.h"
#import "ACDLoginViewController.h"
#import "ACDLogoutViewController.h"
#import "ACDConversationListViewController.h"
#import "ACDGlobals.h"

@implementation ACDAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Create a session with the SDK for all other SDK calls to work
    [ACLIPSession createSessionWithAppID:ACLIPSA_APP_ID serverEnvironment:ACLIPStagingServer];
    
    [[UINavigationBar appearance] setTintColor:NAV_BAR_TINT];
    [[UIBarButtonItem appearance] setTintColor:NAV_BAR_BUTTON_TINT];
    [[UIToolbar appearance] setTintColor:NAV_BAR_TINT];
	
	[self setTabBarController:(UITabBarController *)[[self window] rootViewController]];

    [[self window] makeKeyAndVisible];
	
	[self showLogin:NO];
	
    return YES;
}

- (NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
    return [self windowInterfaceOrientations:window];
}

- (void)showLogin:(BOOL)animated
{
    UINavigationController *loginNavController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"LoginNavigationController"];
    [[self tabBarController] presentViewController:loginNavController animated:animated completion:nil];
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

#pragma mark - Helpers

- (NSUInteger)windowInterfaceOrientations:(UIWindow *)window
{
    if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive && [[window rootViewController] isKindOfClass:[UITabBarController class]])
        return [[[[(UITabBarController *)[window rootViewController] selectedViewController] presentedViewController] presentedViewController] isKindOfClass:[MPMoviePlayerViewController class]] || [[[(UITabBarController *)[window rootViewController] selectedViewController] presentedViewController] isKindOfClass:[MPMoviePlayerViewController class]] ? UIInterfaceOrientationMaskAllButUpsideDown : UIInterfaceOrientationMaskPortrait;
    
    return UIInterfaceOrientationMaskPortrait;
}

@end
