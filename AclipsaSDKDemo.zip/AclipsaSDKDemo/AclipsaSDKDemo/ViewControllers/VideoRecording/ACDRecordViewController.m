//
//  ACDRecordViewController.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDRecordViewController.h"
#import <AclipsaSDK/AclipsaSDK.h>
#import <QuartzCore/QuartzCore.h>
#import "AVCamCaptureManager.h"
#import "ACDGlobals.h"

@implementation ACDRecordViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    AVCamCaptureManager *manager = [[AVCamCaptureManager alloc] init];
    [self setCaptureManager:manager];
    
    [[self captureManager] setDelegate:self];
    
    if ([[self captureManager] setupSession]) {
        AVCaptureVideoPreviewLayer *newCaptureVideoPreviewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:[[self captureManager] session]];
        UIView *view = [self cameraView];
        CALayer *viewLayer = [view layer];
        [viewLayer setMasksToBounds:YES];
        
        CGRect bounds = view.layer.bounds;
        newCaptureVideoPreviewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
        newCaptureVideoPreviewLayer.bounds = bounds;
        newCaptureVideoPreviewLayer.position = CGPointMake(CGRectGetMidX(bounds), CGRectGetMidY(bounds));
        
        [viewLayer insertSublayer:newCaptureVideoPreviewLayer below:[[viewLayer sublayers] objectAtIndex:0]];
        
        [self setCaptureVideoPreviewLayer:newCaptureVideoPreviewLayer];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sessionStartedRunning) name:AVCaptureSessionDidStartRunningNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sessionStoppedRunning) name:AVCaptureSessionDidStopRunningNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sessionError:) name:AVCaptureSessionRuntimeErrorNotification object:nil];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)sessionStartedRunning
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if ([[[self captureManager] session] isRunning]) {
            [[self recordButtonImageView] setImage:[UIImage imageNamed:@"TabBarRecordButtonReady"]];
            
            [[self timerView] setUserInteractionEnabled:YES];
        }
    });
}

- (void)sessionStoppedRunning
{
    if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive) {
        [self startCamera];
    }
}

- (void)sessionError:(NSNotification *)notif
{    
    [[self timerView] setUserInteractionEnabled:YES];
    
    if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [[[self captureManager] session] stopRunning];
            [self startCamera];
        });
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if ([self spaceAvailable])
    {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [[[self captureManager] session] startRunning];
        });
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Cannot Record Video", @"") message:NSLocalizedString(@"There is not enough available storage to record video.", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
        [alert show];
        
        [[self timerView] setUserInteractionEnabled:YES];
    }
    
    [[self torchButton] setHidden:![[self captureManager] canUseFlashlight]];
    [[self flipButton] setHidden:![[self captureManager] canFlipCamera]];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
                        
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [[[self captureManager] session] stopRunning];
    });
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    [[self captureManager] setDelegate:nil];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [[[self captureManager] session] stopRunning];
    });
    
    if ([self flashlightOn]) {
        [self setFlashlightOn:NO];
        [[self torchButton] setBackgroundImage:[UIImage imageNamed:@"FlashOff"] forState:UIControlStateNormal];
    }
    
    [[self timerView] setUserInteractionEnabled:YES];
}

- (BOOL)shouldAutorotate
{
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAllButUpsideDown;
}

#pragma mark RecordingControllerDelegate methods

- (void)didSaveVideoToURL:(NSURL *)inUrl
{
    [self setMovieUrl:inUrl];
    [[self delegate] finishedRecordingURL:[self movieUrl] thumbnailImage:[UIImage getThumbnailFromURL:[self movieUrl] size:CGSizeMake(360.0, 360.0)]];
}

- (void)failedToSaveVideo
{
    [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
    
    [self setCapturing:NO];
    [[self flipButton] setHidden:![[self captureManager] canFlipCamera]];
    [[self captureManager] stopRecording];
    
    if ([self flashlightOn]) {
        [self setFlashlightOn:NO];
        [[self torchButton] setBackgroundImage:[UIImage imageNamed:@"FlashOff"] forState:UIControlStateNormal];
    }
}

- (void)captureManagerDidToggleCamera:(AVCamCaptureManager *)captureManager
{
    [self cameraFlip];
}

#pragma mark Camera methods

- (IBAction)cameraTapped
{
    if(![self capturing])
    {
        [self recordStart];
    }
    else
    {
        [[self timerView] setUserInteractionEnabled:NO];
        [[self recordButtonImageView] setImage:[UIImage imageNamed:@"TabBarRecordButton"]];
        
        [self setCapturing:NO];
        [[self flipButton] setHidden:![[self captureManager] canFlipCamera]];
        [[self captureManager] stopRecording];
        
        [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
                
        if ([self flashlightOn]) {
            [self setFlashlightOn:NO];
            [[self torchButton] setBackgroundImage:[UIImage imageNamed:@"FlashOff"] forState:UIControlStateNormal];
        }
    }
}

- (void)recordStart
{    
    [self setCapturing:YES];
    [[self flipButton] setHidden:YES];
    
    [[self recordButtonImageView] setImage:[UIImage imageNamed:@"TabBarRecordButton"]];
    
    [[self captureManager] startRecording];
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
}

- (IBAction)flipButtonTapped:(id)sender
{
    [[self captureManager] toggleCamera];
    
    [[self torchButton] setHidden:![[self captureManager] canUseFlashlight]];
    
    if ([self flashlightOn]) {
        [self setFlashlightOn:NO];
        [[self torchButton] setBackgroundImage:[UIImage imageNamed:@"FlashOff"] forState:UIControlStateNormal];
    }
}

- (IBAction)torchButtonTapped:(id)sender
{
    if ([self flashlightOn]) {
        [self setFlashlightOn:NO];
        [[self torchButton] setBackgroundImage:[UIImage imageNamed:@"FlashOff"] forState:UIControlStateNormal];
    }
    else {
        [self setFlashlightOn:YES];
        [[self torchButton] setBackgroundImage:[UIImage imageNamed:@"FlashOn"] forState:UIControlStateNormal];
    }
    
    [[self captureManager] toggleFlashlight];
}

- (BOOL)spaceAvailable
{
    NSError *err;
    NSFileManager *fman = [NSFileManager defaultManager];
    
    NSString *path = [[[fman URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject] path];
    NSDictionary *fattr = [fman attributesOfFileSystemForPath:path error:&err];
    
    NSUInteger freeSize = [[fattr objectForKey:NSFileSystemFreeSize] unsignedIntegerValue];
    
    return freeSize > MIN_FREE_DISK_SPACE;
}

- (void)startCamera
{
    if ([self spaceAvailable])
    {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [[[self captureManager] session] startRunning];
        });
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Cannot Record Video", @"") message:NSLocalizedString(@"There is not enough available storage to record video.", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
        [alert show];
        
        [[self timerView] setUserInteractionEnabled:YES];
    }
}

- (void)cameraFlip
{
    [UIView transitionWithView:self.view duration:.5 options:UIViewAnimationOptionTransitionFlipFromRight animations:nil completion:nil];
}

@end