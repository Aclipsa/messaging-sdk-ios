//
//  ACDRecordViewController.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AVCamCaptureManager.h"

@class AVCaptureVideoPreviewLayer;

@protocol ACDRecordViewControllerDelegate <NSObject>
- (void)finishedRecordingURL:(NSURL *)videoURL thumbnailImage:(UIImage *)thumbnailImage;
@end

@interface ACDRecordViewController : UIViewController <UIVideoEditorControllerDelegate, UINavigationControllerDelegate, AVCamCaptureManagerDelegate, UIAlertViewDelegate>

@property (nonatomic, assign) id <ACDRecordViewControllerDelegate> delegate;
@property (nonatomic,retain) AVCamCaptureManager *captureManager;
@property (nonatomic,retain) AVCaptureVideoPreviewLayer *captureVideoPreviewLayer;
@property (nonatomic) BOOL capturing;
@property (nonatomic, assign) BOOL flashlightOn;
@property (strong, nonatomic) NSURL *movieUrl;
@property (strong, nonatomic) NSTimer *timer;

@property (nonatomic, strong) IBOutlet UIView *overlayView;
@property (nonatomic, strong) IBOutlet UIView *cameraView;
@property (strong, nonatomic) IBOutlet UIButton *flipButton;
@property (strong, nonatomic) IBOutlet UIButton *torchButton;

@property (strong, nonatomic) IBOutlet UIView *timerView;
@property (strong, nonatomic) IBOutlet UIImageView *recordButtonImageView;

- (BOOL)spaceAvailable;
- (void)startCamera;
- (void)cameraTapped;
- (void)sessionStartedRunning;

- (IBAction)flipButtonTapped:(id)sender;

@end
