//
//  ACDUploadVideoController.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACDUploadVideoController : UIViewController <UINavigationControllerDelegate, UIImagePickerControllerDelegate>

@property (strong, nonatomic) IBOutlet UIButton *selectButton;
@property (strong, nonatomic) IBOutlet UIButton *uploadButton;
@property (strong, nonatomic) IBOutlet UITextField *titleTextField;
@property (strong, nonatomic) IBOutlet UILabel *progressLabel;
@property (strong, nonatomic) IBOutlet UISwitch *encryptedSwitch;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UIView *contentView;

@property (nonatomic, retain) UIImagePickerController *videoPicker;

@property (nonatomic, retain) NSDictionary *videoInfo;

@property (nonatomic, assign) BOOL isKeyBoardShowing;
@property (nonatomic, assign) CGFloat savedScrollViewHeight;
@property (nonatomic, assign) CGFloat keyboardTopPosition;

- (IBAction)selectVideoPressed:(id)sender;
- (IBAction)uploadVideoPressed:(id)sender;

@end
