//
//  ACDUploadVideoController.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDUploadVideoController.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <AclipsaSDK/AclipsaSDK.h>
#import "ACDGlobals.h"

@interface ACDUploadVideoController ()

@property (strong, nonatomic) ACLIPVideo *uploadingVideo;

@end

@implementation ACDUploadVideoController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:[[self view] window]];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:[[self view] window]];
}

- (void)viewDidAppear:(BOOL)animated
{
    [[self scrollView] setContentSize:[[self contentView] frame].size];
    
    [super viewDidAppear:animated];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
	if ([keyPath isEqualToString:@"state"])
	{
		switch ((ACLIPVideoStateType)[object state])
		{
			case ACLIPVideoCompressingState:
				[_progressLabel setText:@"Compressing Video"];
				break;
			case ACLIPVideoUploadingState:
				[_progressLabel setText:@"Uploaded: 0%%"];
				break;
			case ACLIPVideoProcessingState:
				[_progressLabel setText:[NSString stringWithFormat:@"Processing Video: %@", [_uploadingVideo title]]];
				[self setUploadingVideo:nil];
				[_uploadButton setEnabled:NO];
				[_selectButton setTitle:@"Select Video" forState:UIControlStateNormal];
				[_titleTextField setText:@""];
				break;
			case ACLIPVideoCompletedState:
				[_progressLabel setText:@"Video Done"];
				break;
			default:
				[_progressLabel setText:@""];
				break;
		}
	}
	else if ([keyPath isEqualToString:@"uploadProgress"])
	{
		CGFloat progress = [object uploadProgress] * 100;
		[_progressLabel setText:[NSString stringWithFormat:@"Uploaded: %.2f%%", progress]];
	}
	else
	{
		[super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
	}
}

#pragma mark - Actions

- (IBAction)selectVideoPressed:(id)sender
{
    [self setVideoPicker:[[UIImagePickerController alloc] init]];
    [[self videoPicker] setDelegate:self];
    [[self videoPicker] setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    [[self videoPicker] setMediaTypes:[[NSArray alloc] initWithObjects:(NSString *)kUTTypeMovie, nil]];
    
	[self presentViewController:[self videoPicker] animated:YES completion:nil];
}

- (IBAction)uploadVideoPressed:(id)sender
{
	[_titleTextField resignFirstResponder];
	
    // Use the SDK to upload a video. By default, these videos can be viewed by any user.
	ACLIPVideo *video = [[ACLIPSession activeSession] uploadVideoAtURL:[[self videoInfo] objectForKey:UIImagePickerControllerMediaURL] title:[_titleTextField text] attributes:nil skipEncoding:![[self encryptedSwitch] isOn] completeBlock:nil errorBlock:^(NSError *error)
	{
		NSLog(@"An error occured while uploading: %@", error);
	}];
	
	[self setUploadingVideo:video];
	[video addObserver:self forKeyPath:@"state" options:NSKeyValueObservingOptionNew context:nil];
	[video addObserver:self forKeyPath:@"uploadProgress" options:NSKeyValueObservingOptionNew context:nil];
}

#pragma mark - UITextFieldDelegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([[self titleTextField] isFirstResponder])
        [[self titleTextField] resignFirstResponder];
    
    return YES;
}

#pragma mark - UIImagePickerControllerDelegate delegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
	NSURL *ref = [info objectForKey:UIImagePickerControllerReferenceURL];
	
	[self setVideoInfo:info];
	[self dismissViewControllerAnimated:YES completion:nil];
	[_uploadButton setEnabled:YES];
	[_selectButton setTitle:[ref lastPathComponent] forState:UIControlStateNormal];
	[_titleTextField setText:[ref lastPathComponent]];
    [self setVideoPicker:nil];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
    [self setVideoPicker:nil];
}

#pragma mark - UIKeyboard Notifications

- (void)keyboardWillShow:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(-[[self scrollView] contentOffset].y, 0.0, kbSize.height, 0.0);
    [self scrollView].contentInset = contentInsets;
    [self scrollView].scrollIndicatorInsets = contentInsets;
}

- (void)keyboardWillHide:(NSNotification*)aNotification
{
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0);
    [self scrollView].contentInset = contentInsets;
    [self scrollView].scrollIndicatorInsets = contentInsets;
}

@end
