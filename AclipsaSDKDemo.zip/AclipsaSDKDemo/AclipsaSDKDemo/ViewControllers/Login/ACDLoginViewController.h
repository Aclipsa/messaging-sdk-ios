//
//  ACDLoginViewController.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACDLoginViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextField *userIDTextField;
@property (nonatomic, strong) IBOutlet UIButton *loginButton;

- (IBAction)loginButtonPushed:(id)sender;

@end
