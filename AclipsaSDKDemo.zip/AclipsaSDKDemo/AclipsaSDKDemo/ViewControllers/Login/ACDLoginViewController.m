//
//  ACDLoginViewController.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDLoginViewController.h"
#import <AclipsaSDK/AclipsaSDK.h>
#import "ACDGlobals.h"
#import <QuartzCore/QuartzCore.h>

@interface ACDLoginViewController ()

@end

@implementation ACDLoginViewController

- (id)initWithNibName:(NSString*)nibNameOrNil bundle:(NSBundle*)nibBundleOrNil
{
	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
	if (self)
	{
		[self setTitle:NSLocalizedString(@"Login", @"")];
	}
    
	return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)]) {
        [self setEdgesForExtendedLayout:UIRectEdgeNone];
    }
    
    [[_userIDTextField layer] setBorderWidth:1.0];
    [[_userIDTextField layer] setCornerRadius:10.0];
    [[_userIDTextField layer] setBorderColor:[UIColor lightGrayColor].CGColor];
        
    [_userIDTextField setText:@""];
}

- (IBAction)loginButtonPushed:(id)sender
{
    if (![[_userIDTextField text] isEqualToString:@""] && [_userIDTextField text]) {
        // Log in to the SDK to view/send videos and messages.
        [[ACLIPSession activeSession] loginWithUserID:[_userIDTextField text] completionBlock:^(id results)
         {
             [self dismissViewControllerAnimated:YES completion:nil];
         } errorBlock:^(NSError *error)
         {
             NSLog(@"An error occured while logging in: %@", error);
         }];
    }
}

@end
