//
//  ACDDetailViewController.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACDRecordViewController.h"

@class ACLIPMessage, ACDNameCell;

@interface ACDDetailViewController : UIViewController <UITableViewDataSource, UITabBarDelegate, ACDRecordViewControllerDelegate>

@property (nonatomic, strong) ACLIPMessage *message;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) IBOutlet UIView *contentView;
@property (nonatomic, strong) IBOutlet UIImageView *thumbnailImageView;
@property (nonatomic, strong) IBOutlet UIButton *playButton;
@property (nonatomic, strong) IBOutlet UILabel *titleLabel;
@property (nonatomic, strong) IBOutlet UILabel *dateLabel;
@property (nonatomic, strong) IBOutlet UILabel *descriptionLabel;
@property (nonatomic, strong) IBOutlet UILabel *fromLabel;
@property (nonatomic, strong) IBOutlet UILabel *fromTitleLabel;
@property (nonatomic, strong) IBOutlet UILabel *toTitleLabel;
@property (nonatomic, strong) IBOutlet UIButton *yankButton;
@property (nonatomic, strong) IBOutlet UIButton *deleteButton;
@property (nonatomic, strong) IBOutlet UIButton *forwardButton;
@property (nonatomic, strong) IBOutlet UIButton *replyButton;
@property (nonatomic, strong) IBOutlet UITableView *nameTableView;
@property (nonatomic, strong) IBOutlet UIImageView *yankedImageView;
@property (nonatomic, strong) IBOutlet UIView *videoView;

@property (nonatomic, strong) IBOutlet NSLayoutConstraint *tableHeightConstraint;
@property (nonatomic, strong) IBOutlet NSLayoutConstraint *contentViewHeightConstraint;

- (IBAction)playButtonTapped:(id)sender;
- (IBAction)yankTapped:(id)sender;
- (IBAction)deleteTapped:(id)sender;
- (IBAction)forwardTapped:(id)sender;
- (IBAction)replyTapped:(id)sender;

@end
