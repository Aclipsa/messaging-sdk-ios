//
//  ACDDetailViewController.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDDetailViewController.h"
#import "ACDNameCell.h"
#import "ACDSendMessageViewController.h"
#import "ACDGlobals.h"
#import "UIImageView+AspectSize.h"
#import <AclipsaSDK/AclipsaSDK.h>

@interface ACDDetailViewController ()

@end

@implementation ACDDetailViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setTitle:[[[self message] sender] userID]];
        
    UIImage *placeholder = [UIImage imageNamed:@"loading"];
    [[self thumbnailImageView] setImageWithVideo:[[self message] video] placeholderImage:placeholder completeBlock:nil];
    
    [[self titleLabel] setText:[[self message] title]];
    [[self descriptionLabel] setText:[[self message] messageText]];
    [[self fromLabel] setText:[[[self message] sender] userID]];
    
    if (![[self message] messageText] || [[[self message] messageText] isEqualToString:@""]) {
        [[self descriptionLabel] setHidden:YES];
    }
    
    if (![[self message] title] || [[[self message] title] isEqualToString:@""]) {
        [[self titleLabel] setHidden:YES];
    }
    
    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
    [formatter setAMSymbol:@"AM"];
    [formatter setPMSymbol:@"PM"];
    [formatter setDateFormat:@"MM/dd/yyyy hh:mm a"];
    [formatter setTimeZone:[NSTimeZone localTimeZone]];
    
    [[self dateLabel] setText:[formatter stringFromDate:[[self message] createdDate]]];
    
    if ([[[[self message] sender] userID] isEqualToString:[[ACLIPSession activeSession] userID]]) {
        [[self yankedImageView] setHidden:[[self message] isYanked] ? NO : YES];
    }
    
    if ([[self message] sender] == [ACLIPUser me]) {
        [[self forwardButton] setHidden:NO];
        [[self yankButton] setHidden:NO];
    }
    else {
        [[self forwardButton] setHidden:YES];
        [[self yankButton] setHidden:YES];
    }
    
    if (![[self message] isRead]) {
        [[self message] markMessageReadCompleteBlock:nil errorBlock:^(NSError *error) {
            NSLog(@"An error occured while marking message read: %@", error);
        }];
    }
}

- (void)viewDidLayoutSubviews
{
    [[self tableHeightConstraint] setConstant:[self calculateTableSize].height];
    [[self contentViewHeightConstraint] setConstant:[[self nameTableView] frame].origin.y + [self tableHeightConstraint].constant + 8];
    
    [[self scrollView] setContentSize:[[self contentView] frame].size];
    
    [super viewDidLayoutSubviews];
}

- (void)popIfNeeded
{
    NSDictionary *userInfo = [NSDictionary dictionaryWithObject:[self message] forKey:@"message"];
    [[NSNotificationCenter defaultCenter] postNotificationName:ACDRefreshNotification object:nil userInfo:userInfo];
    
    [[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Message Not Available", @"") message:NSLocalizedString(@"The message is no longer available.", @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil] show];
    
    if ([[[[self message] messageThread] messages] count] > 1) {
        [[self navigationController] popViewControllerAnimated:YES];
    }
    else {
        [[self navigationController] popToRootViewControllerAnimated:YES];
    }
}

#pragma mark - IBActions

- (IBAction)playButtonTapped:(id)sender
{
    // Use the SDK to reload a message before trying to view it. This ensures the message is still available to the recipient.
    [[ACLIPSession activeSession] loadMessageWithGUID:[[self message] guid] completeBlock:^(ACLIPMessage *aclipMessage) {
        if (aclipMessage)
        {
            [self setMessage:aclipMessage];
            ACLIPMoviePlayerViewController *controller = [ACLIPMoviePlayerViewController moviePlayerViewControllerForMessage:[self message]];
            [self presentMoviePlayerViewControllerAnimated:controller];
        }
        else {
            [self popIfNeeded];
        }
    } errorBlock:nil];
}

- (IBAction)yankTapped:(id)sender
{
    if ([[self message] isYanked]) {
        // Use the SDK to "unyank" a message from recipients. This makes recipients able to view the message again.
        [[self message] unyankMessageForRecipients:[[[self message] recipients] allObjects] completeBlock:^(id results) {
            [[self yankedImageView] setHidden:YES];
        }
        errorBlock:^(NSError *error) {
            NSLog(@"An error occured while unyanking message: %@", error);
        }];
    }
    else {
        // Use the SDK to "yank" a message from recipients. This makes recipients unable to view the message.
        [[self message] yankMessageForRecipients:[[[self message] recipients] allObjects] completeBlock:^(id results) {
            [[self yankedImageView] setHidden:NO];
        }
        errorBlock:^(NSError *error) {
            NSLog(@"An error occured while yanking message: %@", error);
        }];
    }
}

- (IBAction)deleteTapped:(id)sender
{
    [[self message] deleteMessageCompleteBlock:^(id results) {
        
        NSDictionary *userInfo = [NSDictionary dictionaryWithObject:[self message] forKey:@"message"];
        [[NSNotificationCenter defaultCenter] postNotificationName:ACDRefreshNotification object:nil userInfo:userInfo];
        
        if ([[[[self message] messageThread] messages] count] > 1) {
            [[self navigationController] popViewControllerAnimated:YES];
        }
        else {
            [[self navigationController] popToRootViewControllerAnimated:YES];
        }
    }
    errorBlock:^(NSError *error) {
        NSLog(@"An error occured while deleting message: %@", error);
    }];
}

- (IBAction)replyTapped:(id)sender
{
    ACDRecordViewController *recordViewController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"RecordViewController"];;
    [recordViewController setDelegate:self];
    
    [self presentViewController:recordViewController animated:YES completion:nil];
}

- (IBAction)forwardTapped:(id)sender
{
    ACDSendMessageViewController *sendMessageController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"SendMessageViewController"];
    [sendMessageController setForwardingMessage:[self message]];
    
    [self presentViewController:sendMessageController animated:YES completion:nil];
}

#pragma mark - ACDRecordViewControllerDelegate

- (void)finishedRecordingURL:(NSURL *)videoURL thumbnailImage:(UIImage *)thumbnailImage
{
    [self dismissViewControllerAnimated:NO completion:^(void) {
        ACDSendMessageViewController *sendMessageController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"SendMessageViewController"];
        [sendMessageController setVideoURL:videoURL];
        [sendMessageController setThumbnailImage:thumbnailImage];
        
        NSMutableArray *recipientList = [[[[self message] recipients] allObjects] mutableCopy];
        
        if ([[self message] sender] != [ACLIPUser me]) {
            [recipientList removeObject:[ACLIPUser me]];
            [recipientList addObject:[[self message] sender]];
        }
        
        [sendMessageController setRecipientList:[self stringFromUserList:recipientList]];
        
        [self presentViewController:sendMessageController animated:YES completion:nil];
    }];
}

#pragma mark - TableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ACLIPUser *person = [[[self message] recipients] count] >= [indexPath row] && [[[self message] recipients] count] > 0 ? [[[[self message] recipients] allObjects] objectAtIndex:[indexPath row]] : nil;
    ACLIPMessageStatus *messageStatus = person ? [ACLIPMessageStatus statusForUser:[person userID] messageGuid:[[self message] guid]] : nil;
    
    if ([[self message] sender] == [ACLIPUser me] && messageStatus && [messageStatus screenshotDate])
        return 65;
    else
        if ([[self message] sender] == [ACLIPUser me])
            return 44;
    
    return 21;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[[self message] recipients] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ACDNameCell *cell = (ACDNameCell *)[tableView dequeueReusableCellWithIdentifier:@"NameCell"];
    
    ACLIPUser *person = [[[[self message] recipients] allObjects] objectAtIndex:[indexPath row]];
    
    if (person == [ACLIPUser me]) {
        [[cell nameLabel] setText:NSLocalizedString(@"Me", @"")];
        [[cell nameLabel] setHidden:NO];
    }
    else {
        [[cell nameLabel] setText:[person userID]];
        [[cell nameLabel] setHidden:NO];
    }
    
    [[cell watchedLabel] setHidden:YES];
    [[cell screenshottedLabel] setHidden:YES];
    [[cell screenshotImageView] setHidden:YES];
    
    if ([[self message] sender] == [ACLIPUser me]) {
        ACLIPMessageStatus *messageStatus = [ACLIPMessageStatus statusForUser:[person userID] messageGuid:[[ACLIPMessage messageForGUID:[[self message] guid]] guid]];
        
        if (messageStatus) {
            if ([messageStatus messageRead]) {
                [[cell readImageView] setImage:[UIImage imageNamed:@"WatchedIcon"]];
                [[cell watchedLabel] setText:NSLocalizedString(@"Viewed", @"")];
            }
            else {
                [[cell readImageView] setImage:[UIImage imageNamed:@"UnwatchedIcon"]];
                [[cell watchedLabel] setText:NSLocalizedString(@"Unviewed", @"")];
            }
            
            if ([messageStatus screenshotDate]) {
                [[cell screenshottedLabel] setHidden:NO];
                [[cell screenshotImageView] setImage:[UIImage imageNamed:@"ScreenshotTakenIcon"]];
                [[cell screenshotImageView] setHidden:NO];
            }
            else {
                [[cell screenshottedLabel] setHidden:YES];
                [[cell screenshotImageView] setHidden:YES];
            }
            
            [[cell watchedLabel] setHidden:NO];
        }
    }
    
    return cell;
}

#pragma mark - Helpers

- (CGSize)calculateTableSize
{
    CGFloat height = 0.0;
    for (int i=0; i < [[[self message] recipients] count]; i++) {
        height += [self tableView:[self nameTableView] heightForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
    }
    
    return CGSizeMake([[self nameTableView] frame].size.width, height);
}

- (NSString *)stringFromUserList:(NSArray *)userList
{
    if ([userList count] > 0) {
        NSArray *IDArray = [userList valueForKey:@"userID"];
        return [IDArray componentsJoinedByString:@", "];
    }

    return @"";
}


@end
