//
//  ACDNameCell.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ACLIPMessage;

@interface ACDNameCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UIImageView *readImageView;
@property (nonatomic, strong) IBOutlet UIImageView *screenshotImageView;
@property (nonatomic, strong) IBOutlet UILabel *nameLabel;
@property (nonatomic, strong) IBOutlet UILabel *watchedLabel;
@property (nonatomic, strong) IBOutlet UILabel *screenshottedLabel;

@end
