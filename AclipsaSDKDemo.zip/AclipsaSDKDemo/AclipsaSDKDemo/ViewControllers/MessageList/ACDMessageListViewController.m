//
//  ACDMessageListViewController.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDMessageListViewController.h"
#import <AclipsaSDK/AclipsaSDK.h>
#import "ACDMessageToMeCell.h"
#import "ACDMessageFromMeCell.h"
#import "ACDDetailViewController.h"
#import "ACDGlobals.h"

@interface ACDMessageListViewController ()

@end

@implementation ACDMessageListViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setTitle:NSLocalizedString(@"Messages", @"")];
        
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshMessages:) name:ACDRefreshNotification object:nil];
}

#pragma mark - Table view data source

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60.0;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView*)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
	return [[self messages] count];
}

- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
    ACDMessageToMeCell *cell = nil;
    
    ACLIPMessage *message = [[self messages] objectAtIndex:[indexPath row]];

    if ([[[message sender] userID] isEqualToString:[[ACLIPSession activeSession] userID]]) {
        cell = (ACDMessageFromMeCell *)[tableView dequeueReusableCellWithIdentifier:@"MessageFromMe"];
    }
    else {
        cell = (ACDMessageToMeCell *)[tableView dequeueReusableCellWithIdentifier:@"MessageToMe"];
    }
    
    [cell configureCellForMessage:message];

	return cell;
}

#pragma mark - Table view Delegates

- (void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath
{
    ACLIPMessage *message = [[self messages] objectAtIndex:[indexPath row]];
    
    // Use the SDK to reload a message before trying to view it. This ensures the message is still available to the recipient.
    [[ACLIPSession activeSession] loadMessageWithGUID:[message guid] completeBlock:^(ACLIPMessage *aclipMessage) {
        if (aclipMessage)
        {
            ACDDetailViewController *detailViewController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"DetailViewController"];
            [detailViewController setMessage:message];
            
            [[self navigationController] pushViewController:detailViewController animated:YES];
            
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
        }
        else {
            [[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Message Not Available", @"") message:NSLocalizedString(@"The message is no longer available.", @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil] show];
            [self removeMessageAndRefresh:message];
        }
    } errorBlock:nil];    
}

#pragma mark - Notification Handlers

- (void)refreshMessages:(NSNotification *)notif
{
    ACLIPMessage *messageToRemove = [[notif userInfo] objectForKey:@"message"];
    [self removeMessageAndRefresh:messageToRemove];
}

- (void)removeMessageAndRefresh:(ACLIPMessage *)message
{
    // Register with the SDK for message polling. SDK checks for messages every 30 seconds. Registering multiple times forces an immediate message poll.
    [[ACLIPSession activeSession] registerMessageLoadingCompletionBlock:nil errorBlock:^(NSError *error) {
        NSLog(@"An error occured while loading messages: %@", error);
    }];
    
    NSMutableArray *messagesCopy = [[self messages] mutableCopy];
    [messagesCopy removeObject:message];
    [self setMessages:messagesCopy];
    
    if ([[[message messageThread] messages] count] > 0) {
        [[self tableView] reloadData];
    }
    else {
        [[self navigationController] popViewControllerAnimated:YES];
    }
}

@end
