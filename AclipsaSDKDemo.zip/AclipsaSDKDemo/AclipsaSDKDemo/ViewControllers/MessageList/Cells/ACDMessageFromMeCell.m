//
//  ACDMessageFromMeCell.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDMessageFromMeCell.h"

@implementation ACDMessageFromMeCell

@end
