//
//  ACDMessageToMeCell.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDMessageToMeCell.h"
#import <AclipsaSDK/AclipsaSDK.h>

@implementation ACDMessageToMeCell

- (void)configureCellForMessage:(ACLIPMessage *)message
{
    UIImage *placeholder = [UIImage imageNamed:@"loading"];
    
    static NSDateFormatter *formatter;
    if (!formatter) {
        formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"MM/dd/yyyy"];
        [formatter setTimeZone:[NSTimeZone localTimeZone]];
    }
    
    [[self dateLabel] setText:[formatter stringFromDate:[message createdDate]]];
    
	[[self senderLabel] setText:[[message sender] userID]];
	[[self thumbnailImageView] setImageWithVideo:[message video] placeholderImage:placeholder];
    
    if ([message isRead])
        [[self messageReadView] setBackgroundColor:[UIColor clearColor]];
    else
        [[self messageReadView] setBackgroundColor:[UIColor greenColor]];
}

@end
