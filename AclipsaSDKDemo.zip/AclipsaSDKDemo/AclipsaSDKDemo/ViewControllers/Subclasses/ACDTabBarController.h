//
//  ACDTabBarController.h
//  AclipsaSDKDemo
//
//  Created by Kevin Macaulay on 10/28/14.
//  Copyright (c) 2014 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACDTabBarController : UITabBarController

@end
