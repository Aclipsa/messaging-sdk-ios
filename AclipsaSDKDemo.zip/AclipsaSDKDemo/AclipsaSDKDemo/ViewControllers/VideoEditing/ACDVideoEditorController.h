//
//  ACDVideoEditorController.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACDVideoEditorController : UIVideoEditorController

@end
