//
//  ACDConversationListViewController.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDConversationListViewController.h"
#import "ACDConversationCell.h"
#import "ACDMessageListViewController.h"
#import "ACDSendMessageViewController.h"
#import "ACDGlobals.h"

#import <AclipsaSDK/AclipsaSDK.h>

@implementation ACDConversationListViewController

- (id)initWithNibName:(NSString*)nibNameOrNil bundle:(NSBundle*)nibBundleOrNil
{
	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
	if (self)
	{
		[self setTitle:NSLocalizedString(@"Conversations", @"")];
        [[self tabBarItem] setImage:[UIImage imageNamed:@"Conversations"]];
        [[self tabBarItem] setImageInsets:UIEdgeInsetsMake(5, 0, -5, 0)];
        
        [[self navigationItem] setLeftBarButtonItem:[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Refresh", @"") style:UIBarButtonItemStylePlain target:self action:@selector(refreshVideos:)]];
        [[self navigationItem] setRightBarButtonItem:[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Record", @"") style:UIBarButtonItemStylePlain target:self action:@selector(recordMessage:)]];
	}
    
	return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
        
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(logout) name:ACDLogoutNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshMessages) name:ACDRefreshNotification object:nil];
    
    // Register with the SDK for message polling. SDK checks for messages every 30 seconds
    [[ACLIPSession activeSession] registerMessageLoadingCompletionBlock:^(NSArray *messages, NSArray *threads) {
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"lastMessage.createdDate" ascending:NO];
        
        [self setMessageThreads:[threads sortedArrayUsingDescriptors:@[sortDescriptor]]];
        [[self tableView] reloadData];
	}
    errorBlock:^(NSError *error) {
        NSLog(@"An error occured while loading messages: %@", error);
    }];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    // Register with the SDK for message polling. SDK checks for messages every 30 seconds. Registering multiple times forces an immediate message poll.
    [[ACLIPSession activeSession] registerMessageLoadingCompletionBlock:^(NSArray *messages, NSArray *threads) {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"messages.@count > 0"];
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"lastMessage.createdDate" ascending:NO];
        
        [self setMessageThreads:[[threads filteredArrayUsingPredicate:predicate] sortedArrayUsingDescriptors:@[sortDescriptor]]];
        [[self tableView] reloadData];
	}
    errorBlock:^(NSError *error) {
        NSLog(@"An error occured while loading messages: %@", error);
    }];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"RecordVideo"])
    {
        ACDRecordViewController *recordViewController = (ACDRecordViewController *)segue.destinationViewController;
        [recordViewController setDelegate:self];
    }
    else if ([segue.identifier isEqualToString:@"MessageList"]) {
        ACLIPMessageThread *messageThread = [[self messageThreads] objectAtIndex:[[[self tableView] indexPathForSelectedRow] row]];
        ACDMessageListViewController *messageListViewController = (ACDMessageListViewController *)segue.destinationViewController;
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"createdDate" ascending:NO];
        [messageListViewController setMessages:[[[messageThread messages] allObjects] sortedArrayUsingDescriptors:@[sortDescriptor]]];
        
        [[self tableView] deselectRowAtIndexPath:[[self tableView] indexPathForSelectedRow] animated:YES];
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView*)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
	return [[self messageThreads] count];
}

- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
    ACDConversationCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ConversationCell"];
    
    ACLIPMessageThread *messageThread = [[self messageThreads] objectAtIndex:[indexPath row]];
    
    [cell configureCellForMessageThread:messageThread];
    
	return cell;
}

#pragma mark - Table view Delegates

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50.0;
}

#pragma mark - New Message

- (void)finishedRecordingURL:(NSURL *)videoURL thumbnailImage:(UIImage *)thumbnailImage
{
    [self dismissViewControllerAnimated:NO completion:^(void) {
        ACDSendMessageViewController *sendMessageController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"SendMessageViewController"];
        [sendMessageController setVideoURL:videoURL];
        [sendMessageController setThumbnailImage:thumbnailImage];
        
        [self presentViewController:sendMessageController animated:YES completion:nil];
    }];
}

#pragma mark - Notification Handler

- (void)logout
{
    [[self navigationController] popToRootViewControllerAnimated:NO];
    [self setMessageThreads:nil];
    [[self tableView] reloadData];
}

- (void)refreshMessages
{
    [self refreshMessages:nil];
}

#pragma mark - Refresh

- (IBAction)refreshMessages:(id)sender
{
    // Register with the SDK for message polling. SDK checks for messages every 30 seconds. Registering multiple times forces an immediate message poll.
    [[ACLIPSession activeSession] registerMessageLoadingCompletionBlock:^(NSArray *messages, NSArray *threads) {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"messages.@count > 0"];
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"lastMessage.createdDate" ascending:NO];
        
        [self setMessageThreads:[[threads filteredArrayUsingPredicate:predicate] sortedArrayUsingDescriptors:@[sortDescriptor]]];
        [[self tableView] reloadData];
	}
    errorBlock:^(NSError *error) {
        NSLog(@"An error occured while loading messages: %@", error);
    }];
}

@end
