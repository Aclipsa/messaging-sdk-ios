//
//  ACDConversationCell.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ACLIPMessageThread;

@interface ACDConversationCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UILabel *usersLabel;
@property (nonatomic, strong) IBOutlet UILabel *dateLabel;

- (void)configureCellForMessageThread:(ACLIPMessageThread *)messageThread;

@end
