//
//  ACDConversationCell.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDConversationCell.h"
#import <AclipsaSDK/AclipsaSDK.h>

@implementation ACDConversationCell

- (void)configureCellForMessageThread:(ACLIPMessageThread *)messageThread
{
	[[self usersLabel] setText:[messageThread userListString]];
    
    static NSDateFormatter *formatter;
    if (!formatter) {
        formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"MM/dd/yyyy"];
        [formatter setTimeZone:[NSTimeZone localTimeZone]];
    }
    
    [[self dateLabel] setText:[formatter stringFromDate:[[messageThread lastMessage] createdDate]]];
}

@end
