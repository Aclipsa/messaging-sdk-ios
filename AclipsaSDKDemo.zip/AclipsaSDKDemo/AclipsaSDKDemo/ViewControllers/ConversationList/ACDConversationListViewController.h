//
//  ACDConversationListViewController.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACDRecordViewController.h"

@class ACDConversationCell;

@interface ACDConversationListViewController : UITableViewController <ACDRecordViewControllerDelegate>

@property (nonatomic, strong) NSArray *messageThreads;

- (IBAction)refreshMessages:(id)sender;

@end
