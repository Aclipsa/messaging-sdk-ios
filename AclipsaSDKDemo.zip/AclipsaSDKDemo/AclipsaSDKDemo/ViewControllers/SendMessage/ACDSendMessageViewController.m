//
//  ACDSendMessageViewController.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDSendMessageViewController.h"
#import "ACDVideoEditorController.h"
#import "ACDMoviePlayerViewController.h"
#import "ACDGlobals.h"

#import <MobileCoreServices/MobileCoreServices.h>
#import <AclipsaSDK/AclipsaSDK.h>
#import <QuartzCore/QuartzCore.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <AVFoundation/AVFoundation.h>

@interface ACDSendMessageViewController ()

@property (strong, nonatomic) ACLIPVideo *uploadingVideo;

@end

@implementation ACDSendMessageViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    	
    [_sendButton setEnabled:YES];
    
    [[[self recipientsTextField] layer] setBorderWidth:1.0];
    [[[self recipientsTextField] layer] setCornerRadius:10.0];
    [[[self recipientsTextField] layer] setBorderColor:[UIColor lightGrayColor].CGColor];
    
    [[[self titleTextField] layer] setBorderWidth:1.0];
    [[[self titleTextField] layer] setCornerRadius:10.0];
    [[[self titleTextField] layer] setBorderColor:[UIColor lightGrayColor].CGColor];
    
    [[[self descriptionTextView] layer] setBorderWidth:1.0];
    [[[self descriptionTextView] layer] setCornerRadius:10.0];
    [[[self descriptionTextView] layer] setBorderColor:[UIColor lightGrayColor].CGColor];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:[[self view] window]];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:[[self view] window]];
}

- (void)viewDidAppear:(BOOL)animated
{
    [[self scrollView] setContentSize:[[self contentView] frame].size];
    
    [super viewDidAppear:animated];
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    if ([self sentMessage]) {
        @try {
            [[[self sentMessage] video] removeObserver:self forKeyPath:@"state"];
            [[[self sentMessage] video] removeObserver:self forKeyPath:@"uploadProgress"];
        }
        @catch (NSException *exception) {
            NSLog(@"Observer couldn't be removed");
        }
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if ([self recipientList]) {
        [[self recipientsTextField] setText:[self recipientList]];
    }
    
    if ([self forwardingMessage]) {
        [[self titleTextField] setText:[[self forwardingMessage] title]];
        [[self descriptionTextView] setText:[[self forwardingMessage] messageText]];
        [[self trimButton] setHidden:YES];
        
        [[self thumbnailImageView] setImageWithURL:[[[self forwardingMessage] video] thumbnailMediumURL] placeholderImage:[UIImage imageNamed:@"loading"]];
    }
    else {
        [[self thumbnailImageView] setImage:[self thumbnailImage]];
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    if (!self.videoPlayback.moviePlayer.isPreparedToPlay) {
        [[[self videoPlayback] moviePlayer] stop];
        [[self playButton] setUserInteractionEnabled:YES];
        
        [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMediaPlaybackIsPreparedToPlayDidChangeNotification object:nil];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
	if ([keyPath isEqualToString:@"state"])
	{
		switch ((ACLIPVideoStateType)[object state])
		{
			case ACLIPVideoCompressingState:
				[_progressLabel setText:@"Compressing Video"];
                [_sendButton setEnabled:NO];
				break;
			case ACLIPVideoUploadingState:
				[_progressLabel setText:@"Uploaded: 0%%"];
                [_sendButton setEnabled:NO];
				break;
			case ACLIPVideoProcessingState:
				[_progressLabel setText:[NSString stringWithFormat:@"Processing Video"]];
				[self setUploadingVideo:nil];
				[_sendButton setEnabled:NO];
				[_titleTextField setText:@""];
				break;
			case ACLIPVideoCompletedState:
				[_progressLabel setText:@"Video Done"];
                [[self sendingSpinner] stopAnimating];
                [self cancel:nil];
				break;
			default:
				[_progressLabel setText:@""];
				break;
		}
	}
	else if ([keyPath isEqualToString:@"uploadProgress"])
	{
		CGFloat progress = [object uploadProgress] * 100;
		[_progressLabel setText:[NSString stringWithFormat:@"Uploaded: %.2f%%", progress]];
	}
	else
	{
		[super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
	}
}

- (void)cancel:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Actions

- (IBAction)trimVideoPressed:(id)sender
{    
    if ([UIVideoEditorController canEditVideoAtPath:[[self videoURL] path]]) {
        
        ACDVideoEditorController *videoEditor = [[ACDVideoEditorController alloc] init];
        [videoEditor setDelegate:self];
        [videoEditor setVideoPath:[[self videoURL] path]];
        
        [self presentViewController:videoEditor animated:YES completion:nil];
    }
}

- (IBAction)cancelPressed:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)uploadVideoPressed:(id)sender
{
    if (![[_recipientsTextField text] isEqualToString:@""] && [_recipientsTextField text]) {
        if ([_titleTextField isFirstResponder])
            [_titleTextField resignFirstResponder];
        else if ([_descriptionTextView isFirstResponder])
            [_descriptionTextView resignFirstResponder];
        else if ([_recipientsTextField isFirstResponder])
            [_recipientsTextField resignFirstResponder];
        
        if ([self forwardingMessage]) {
            // Use the SDK to forward a message to recipients. Only the sender of a message is allowed to forward it.
            [[ACLIPSession activeSession] forwardMessage:[[self titleTextField] text] messageText:[[self descriptionTextView] text] recipients:[self arrayFromRecipientString] video:[[self forwardingMessage] video] oldMessageGuid:[[self forwardingMessage] guid] newMessageGuid:nil completeBlock:^(id results) {
                [self cancel:nil];
            } errorBlock:^(NSError *error) {
                [[self sendingSpinner] stopAnimating];
                NSLog(@"An error occured while sending message: %@", error);
            }];
        }
        else {
            // Use the SDK to send a message to recipients with an optional title and description.
            [self setSentMessage:[[ACLIPSession activeSession] sendMessage:[[self titleTextField] text] messageText:[[self descriptionTextView] text] recipients:[self arrayFromRecipientString] videoURL:[self videoURL] skipEncoding:![[self encryptedSwitch] isOn] attributes:nil completeBlock:nil errorBlock:^(NSError *error)
            {
                [[self sendingSpinner] stopAnimating];
                NSLog(@"An error occured while sending message: %@", error);
            }]];
            
            [[self sendingSpinner] startAnimating];
            [self setUploadingVideo:[[self sentMessage] video]];
            [[[self sentMessage] video] addObserver:self forKeyPath:@"state" options:NSKeyValueObservingOptionNew context:nil];
            [[[self sentMessage] video] addObserver:self forKeyPath:@"uploadProgress" options:NSKeyValueObservingOptionNew context:nil];
        }
    }
}

- (IBAction)playVideoPressed:(id)sender
{
    if ([self forwardingMessage]) {
        ACLIPMoviePlayerViewController *controller = [ACLIPMoviePlayerViewController moviePlayerViewControllerForVideo:[[self forwardingMessage] video]];
        [self presentMoviePlayerViewControllerAnimated:controller];
    }
    else {
        [self setVideoPlayback:[[ACDMoviePlayerViewController alloc] initWithContentURL:[self videoURL]]];
    
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackIsPreparedToPlayDidChange:) name:MPMediaPlaybackIsPreparedToPlayDidChangeNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(moviePlaybackDidFinish:) name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
    
        NSError *_error = nil;
        [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:&_error];
    
        [[self spinner] startAnimating];
        [[self playButton] setUserInteractionEnabled:NO];
    
        [[[self videoPlayback] moviePlayer] prepareToPlay];
    }
}

#pragma mark - Video Editing

- (void)videoEditorController:(UIVideoEditorController *)editor didSaveEditedVideoToPath:(NSString *)editedVideoPath
{    
    NSString *path = [editedVideoPath stringByReplacingOccurrencesOfString:@"//" withString:@"/"];
    
    [self setVideoURL:[NSURL fileURLWithPath:path]];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)videoEditorController:(UIVideoEditorController *)editor didFailWithError:(NSError *)error
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Video Editing Error", @"") message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)videoEditorControllerDidCancel:(UIVideoEditorController *)editor
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Helpers

- (NSArray *)arrayFromRecipientString
{
    NSString *trimmedString = [[[self recipientsTextField] text] stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    return [trimmedString componentsSeparatedByString:@","];
}

#pragma mark - UITextFieldDelegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([[self recipientsTextField] isFirstResponder])
        [[self titleTextField] becomeFirstResponder];
    else if ([[self titleTextField] isFirstResponder])
        [[self descriptionTextView] becomeFirstResponder];
    
    return YES;
}

#pragma mark - Video Playback

-(void)playbackIsPreparedToPlayDidChange:(NSNotification *)inNotification
{
	if (self.videoPlayback.moviePlayer.isPreparedToPlay)
    {        
        if ([self presentedViewController] != [self videoPlayback])
            [self presentMoviePlayerViewControllerAnimated:[self videoPlayback]];
    }
}

- (void)moviePlaybackDidFinish:(NSNotification*)notification
{
    [[self spinner] stopAnimating];
    [[[self videoPlayback] moviePlayer] stop];
    [self setVideoPlayback:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMediaPlaybackIsPreparedToPlayDidChangeNotification object:nil];
    
    [[self playButton] setUserInteractionEnabled:YES];
}

#pragma mark - UIKeyboard Notifications

- (void)keyboardWillShow:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(-[[self scrollView] contentOffset].y, 0.0, kbSize.height, 0.0);
    [self scrollView].contentInset = contentInsets;
    [self scrollView].scrollIndicatorInsets = contentInsets;
}

- (void)keyboardWillHide:(NSNotification*)aNotification
{
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    [self scrollView].contentInset = contentInsets;
    [self scrollView].scrollIndicatorInsets = contentInsets;
}

@end
