//
//  ACDSendMessageViewController.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

@class ACDMoviePlayerViewController, ACLIPMessage;

@interface ACDSendMessageViewController : UIViewController <UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate, UIVideoEditorControllerDelegate, UIImagePickerControllerDelegate>

@property (strong, nonatomic) IBOutlet UIButton *sendButton;
@property (strong, nonatomic) IBOutlet UIButton *trimButton;
@property (strong, nonatomic) IBOutlet UIButton *cancelButton;
@property (strong, nonatomic) IBOutlet UIButton *playButton;
@property (strong, nonatomic) IBOutlet UITextField *titleTextField;
@property (strong, nonatomic) IBOutlet UITextView *descriptionTextView;
@property (strong, nonatomic) IBOutlet UITextField *recipientsTextField;
@property (strong, nonatomic) IBOutlet UILabel *progressLabel;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (strong, nonatomic) IBOutlet UISwitch *encryptedSwitch;
@property (strong, nonatomic) IBOutlet UIImageView *thumbnailImageView;
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *spinner;
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *sendingSpinner;

@property (nonatomic, strong) NSURL *videoURL;
@property (nonatomic, strong) UIImage *thumbnailImage;
@property (nonatomic, strong) ACDMoviePlayerViewController *videoPlayback;
@property (nonatomic, strong) ACLIPMessage *sentMessage;
@property (nonatomic, strong) NSString *recipientList;
@property (nonatomic, strong) ACLIPMessage *forwardingMessage;

@property (nonatomic, assign) BOOL isKeyBoardShowing;
@property (nonatomic, assign) CGFloat savedScrollViewHeight;
@property (nonatomic, assign) CGFloat keyboardTopPosition;

- (IBAction)uploadVideoPressed:(id)sender;
- (IBAction)trimVideoPressed:(id)sender;
- (IBAction)cancelPressed:(id)sender;
- (IBAction)playVideoPressed:(id)sender;

@end
