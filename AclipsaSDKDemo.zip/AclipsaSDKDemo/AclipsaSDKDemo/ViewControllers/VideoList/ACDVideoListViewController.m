//
//  ACDFirstViewController.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDVideoListViewController.h"
#import "ACDVideoListCell.h"
#import <AclipsaSDK/AclipsaSDK.h>

@interface ACDVideoListViewController ()

@end

@implementation ACDVideoListViewController

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:YES];
    
    // Use the SDK to load the videos available for a user.
	[[ACLIPSession activeSession] loadUserVideosWithCompletionBlock:^(NSArray *results)
	{
        [self setVideos:results];
        [[self tableView] reloadData];
	} errorBlock:^(NSError *error)
	{
        NSLog(@"An error occured while loading videos: %@", error);
	}];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView*)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
	return [[self videos] count];
}

- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
    ACDVideoListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"VideoListCell"];

	[cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];

	ACLIPVideo *video = [[self videos] objectAtIndex:[indexPath row]];
	UIImage *placeholder = [UIImage imageNamed:@"loading"];

	[[cell titleLabel] setText:[video title]];
	[[cell videoImageView] setImageWithVideo:video placeholderImage:placeholder];

	return cell;
}

#pragma mark - Table view Delegates

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44.0;
}

- (void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath
{
    ACLIPVideo *video = [[self videos] objectAtIndex:[indexPath row]];
    
    // Use the SDK to reload a video before trying to view it. This ensures the video is still available to the recipient.
    [[ACLIPSession activeSession] loadUserVideoWithID:[video guid] completionBlock:^(ACLIPVideo *aclipVideo) {
        if (aclipVideo)
        {
            ACLIPMoviePlayerViewController *controller = [ACLIPMoviePlayerViewController moviePlayerViewControllerForVideo:video];
            [self presentMoviePlayerViewControllerAnimated:controller];
        }
    } errorBlock:nil];
    
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Refresh

- (IBAction)refreshVideos:(id)sender
{
    // Use the SDK to load the videos available for a user.
    [[ACLIPSession activeSession] loadUserVideosWithCompletionBlock:^(NSArray *results) {
         [self setVideos:results];
         [[self tableView] reloadData];
    } errorBlock:^(NSError *error) {
         NSLog(@"An error occured while loading videos: %@", error);
    }];
}

@end
