//
//  ACDFirstViewController.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ACDVideoListCell;

@interface ACDVideoListViewController : UITableViewController

@property (strong, nonatomic) NSArray *videos;

- (IBAction)refreshVideos:(id)sender;

@end
