//
//  ACDLogoutViewController.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDLogoutViewController.h"
#import <AclipsaSDK/AclipsaSDK.h>
#import "ACDAppDelegate.h"
#import "ACDGlobals.h"

@interface ACDLogoutViewController ()

@end

@implementation ACDLogoutViewController

- (id)initWithNibName:(NSString*)nibNameOrNil bundle:(NSBundle*)nibBundleOrNil
{
	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
	if (self)
	{
		[self setTitle:NSLocalizedString(@"Log Out", @"")];
        [[self tabBarItem] setImage:[UIImage imageNamed:@"Logout"]];
	}
    
	return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)]) {
        [self setEdgesForExtendedLayout:UIRectEdgeBottom];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[self userIDLabel] setText:[[ACLIPSession activeSession] userID]];
}

- (IBAction)logoutButtonPushed:(id)sender
{
    // Log out of the SDK. Videos cannot be viewed and messages cannot be sent
    [[ACLIPSession activeSession] logoutWithCompletionBlock:^(id results) {
        [[self userIDLabel] setText:@""];
        
        ACDAppDelegate *appDelegate = (ACDAppDelegate*)[[UIApplication sharedApplication] delegate];
        
        [appDelegate showLogin:YES];
        [[appDelegate tabBarController] setSelectedIndex:0];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:ACDLogoutNotification object:nil];
    }
    errorBlock:^(NSError *error) {
        NSLog(@"An error occured while logging out: %@", error);
    }];
}

- (IBAction)deleteAccountPushed:(id)sender
{
    // Delete the user's account. All sent videos will also be deleted
    [[ACLIPSession activeSession] deleteUserWithID:[[ACLIPSession activeSession] userID] completionBlock:^(id results) {
        [[self userIDLabel] setText:@""];
        
        ACDAppDelegate *appDelegate = (ACDAppDelegate*)[[UIApplication sharedApplication] delegate];
        
        [appDelegate showLogin:YES];
        [[appDelegate tabBarController] setSelectedIndex:0];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:ACDLogoutNotification object:nil];
    }
    errorBlock:^(NSError *error) {
        NSLog(@"An error occured while logging out: %@", error);
    }];
}

@end
