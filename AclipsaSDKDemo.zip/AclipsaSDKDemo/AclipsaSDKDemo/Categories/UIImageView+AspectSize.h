//
//  UIImageView+AspectSize.h
//  AclipsaSDKDemo
//
//  Created by Kevin Macaulay on 1/7/14.
//  Copyright (c) 2014 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (AspectSize)

- (CGSize)imageScale;

@end
