//
//  NSString+ACDAdditions.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (ACDAdditions)

+ (NSString*)stringWithUUID;

@end
