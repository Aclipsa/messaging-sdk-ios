//
//  ACDGlobals.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ACDGlobals : NSObject

#define MAX_RECORD_TIME 30
#define MIN_FREE_DISK_SPACE (1024 * 1024)

#define GROW_ANIMATION_DURATION_SECONDS 0.2
#define SHRINK_ANIMATION_DURATION_SECONDS 0.2

#define SECOND 1
#define MINUTE (60 * SECOND)
#define HOUR (60 * MINUTE)
#define DAY (24 * HOUR)
#define MONTH (30 * DAY)

#define ACTION_MENU_TEXT_COLOR [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0]
#define ACTION_MENU_SHADOW_COLOR [UIColor colorWithRed:254/255.0 green:216/255.0 blue:164/255.0 alpha:1]

#define MINUTE_BAR_FIRST_CHUNK [UIColor colorWithRed:255/255.0 green:212/255.0 blue:41/255.0 alpha:1.0]

#define NAV_BAR_TINT [UIColor colorWithRed:88/255.0 green:89/255.0 blue:91/255.0 alpha:1.0]
#define NAV_BAR_BUTTON_TINT [UIColor colorWithRed:88/255.0 green:89/255.0 blue:91/255.0 alpha:1.0]
#define BACKGROUND_COLOR [UIColor colorWithRed:241/255.0 green:242/255.0 blue:242/255.0 alpha:1.0]
#define TEXT_BORDER_COLOR [UIColor colorWithRed:108/255.0 green:114/255.0 blue:127/255.0 alpha:1.0]

#define ACDLogoutNotification @"ACDLogoutNotification"
#define ACDRefreshNotification @"ACDRefreshNotification"

@end
