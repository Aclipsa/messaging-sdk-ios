//
//  ACDAppDelegate.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

#define ACLIPSA_APP_ID @"3113"

@interface ACDAppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UITabBarController *tabBarController;

- (void)showLogin:(BOOL)animated;

@end
