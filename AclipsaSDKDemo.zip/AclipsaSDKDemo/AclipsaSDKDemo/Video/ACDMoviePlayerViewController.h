//
//  ACDMoviePlayerViewController.h
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import <MediaPlayer/MediaPlayer.h>

@interface ACDMoviePlayerViewController : MPMoviePlayerViewController

@end
