//
//  ACDMoviePlayerViewController.m
//  AclipsaSDKDemo
//
//  Copyright (c) 2013 Aclipsa Mobile Video Solutions, LLC. All rights reserved.
//

#import "ACDMoviePlayerViewController.h"

@implementation ACDMoviePlayerViewController

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[self moviePlayer] naturalSize].width >= 480) {
        if (interfaceOrientation == UIInterfaceOrientationPortrait)
            [self moviePlayer].scalingMode = MPMovieScalingModeAspectFit;
        else
            [self moviePlayer].scalingMode = MPMovieScalingModeAspectFill;
    }
    else {
        if (interfaceOrientation == UIInterfaceOrientationPortrait)
            [self moviePlayer].scalingMode = MPMovieScalingModeAspectFill;
        else
            [self moviePlayer].scalingMode = MPMovieScalingModeAspectFit;
    }
    
    return YES;
}

- (BOOL)shouldAutorotate
{    
    if ([[self moviePlayer] naturalSize].width >= 480) {
        if ([UIDevice currentDevice].orientation == UIInterfaceOrientationPortrait) {
            [self moviePlayer].scalingMode = MPMovieScalingModeAspectFit;
        }
        else {
            [self moviePlayer].scalingMode = MPMovieScalingModeAspectFill;
        }
    }
    else {
        if ([UIDevice currentDevice].orientation == UIInterfaceOrientationPortrait) {
            [self moviePlayer].scalingMode = MPMovieScalingModeAspectFill;
        }
        else {
            [self moviePlayer].scalingMode = MPMovieScalingModeAspectFit;
        }
    }
    
    return YES;
}

@end
